﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoria
{
    class Cat : Animal, IDomesticAnimal
    {
        void IDomesticAnimal.Play()
        {
            Console.WriteLine("Miao miao gomitolo!");
        }

        public void Company()
        {
            Console.WriteLine("Fusa.....!");
        }

        public override void Breath()
        {
            Console.WriteLine("ZZzzzzzz!");
        }
    }
}
