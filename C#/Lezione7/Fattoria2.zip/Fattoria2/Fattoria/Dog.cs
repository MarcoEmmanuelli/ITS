﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Fattoria
{
    class Dog : Animal, IDomesticAnimal
    {
        public void Play()
        {
            Console.WriteLine("Bau bau pallina!");
        }

        public void Company()
        {
            Console.WriteLine("Scodinzolo!");
        }

        static public int DogCount = 0;

        public Dog()
        {
            DogCount++;
            Debug.WriteLine("Dog constructor invoked");
            LegsNumber = 4;
            AnimalFamily = Family.Mammals;
            Name = "Cane";
        }

        ~Dog()
        {
            DogCount--;
            Debug.WriteLine("Dog destructor invoked");
        }

        public void Talk()
        {
            Console.WriteLine("BAU!");
        }
        public override void Breath()
        {
            Console.WriteLine(Name + " bau-bau-eggiando!");
        }

        public override string ToString()
        {
            return Name + " " + Legs.ToString();
        }
    }
}
