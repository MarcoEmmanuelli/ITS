﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fibonacci
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Quanti? ");
      string s = Console.ReadLine();
      int quanti = int.Parse(s);

      SerieFibonacci(quanti);
      Console.ReadLine();
    }

    static void SerieFibonacci(int q)
    {
      int a = 0, b = 1, c = 0;
      //long a = 0, b = 1, c = 0;
      //ulong a = 0, b = 1, c = 0;
      Console.Write("{0} {1} ", a, b);

      //Console.Write(a.ToString() + " " + b.ToString() + " ");

      //for (int i = 2; i < q; i++)
      //{
      //    c = a + b;
      //    Console.Write("{0} ", c);
      //    a = b;
      //    b = c;
      //}

      //int i = 2;
      //while (i < q)
      //{
      //    c = a + b;
      //    Console.Write("{0} ", c);
      //    a = b;
      //    b = c;
      //    i++;
      //}

      int i = 2;
      for (; i < q;)
      {
        c = a + b;
        Console.Write("{0} ", c);
        a = b;
        b = c;
        i++;
      }
    }
  }
}
