﻿using System;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                string op1;
                do
                {
                    Console.WriteLine("Primo operando:");
                    op1 = Console.ReadLine();
                }
                while (!Information.IsNumeric(op1));

                string op2;
                int o2;
                do
                {
                    Console.WriteLine("Secondo operando:");
                    op2 = Console.ReadLine();
                }
                while (!int.TryParse(op2, out o2));

                string oper;
                do
                {
                    Console.WriteLine("Operatore (+,-,*,/):");
                    oper = Console.ReadLine();
                }
                while (!"+-*/".Contains(oper) || oper.Length!=1);
                //while (!("+-*/".Contains(oper) && oper.Length == 1)) ;

                int o1 = int.Parse(op1);


                int ris;
                switch (oper)
                {
                    case "+":
                        ris = o1 + o2;
                        break;
                    case "-":
                        ris = o1 - o2;
                        break;
                    case "*":
                        ris = o1 * o2;
                        break;
                    case "/":
                        ris = o1 / o2;
                        break;
                    default:
                        ris = 0;
                        break;
                }
                Console.WriteLine("Risultato: " + ris.ToString());
            }
            while (Console.ReadLine() != "stop");
        }
    }
}
