﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palestra
{
    public static class Extension
    {
        public static string FirstUpper(this string s)
        {
            string[] parole = s.Split(' ');
            for (int i = 0; i < parole.Length; i++)
            {
                parole[i] = parole[i][0].ToString().ToUpper() +
                    parole[i].Substring(1);
            }
            return string.Join(" ", parole);
        }

        public static int WordCount(this string s)
        {
            return s.Split(' ').Length;
        }

        public static string ToUpper(this string s,int i)
        {
            return "pippo INT";
        }


        public static int Doppio(this int i)
        {
            return i + i;
        }

        public static int Moltiplica(this int i, int m)
        {
            return i * m;
        }
    }
}
