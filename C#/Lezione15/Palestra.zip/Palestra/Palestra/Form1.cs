﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Palestra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = "piazza dei mestieri 23";
            textBox1.Text = s.ToUpper(3);

            //textBox1.Text = s.WordCount().ToString();
            //textBox1.Text = s.FirstUpper();

            //int x = 123;
            ////textBox1.Text = x.Doppio().ToString();
            //textBox1.Text = x.Moltiplica(3).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //  08/06/2022
            DateTime d = DateTime.ParseExact(
                textBox2.Text, "ddd dd/MM/yyyy", 
                new CultureInfo("it-it"));


            //decimal dec = decimal.Parse(textBox2.Text,
            //    new CultureInfo("en-US"));
            //textBox1.Text = dec.ToString();

            //textBox1.Text =
            //System.Threading.Thread.CurrentThread
            //.CurrentUICulture.ToString();

            //DateTime d = DateTime.Now;
            //textBox1.Text = d.ToString(@"HH\:mm");

            //decimal dec = 123.456M;
            //textBox1.Text = dec.ToString();


        }
    }
}
