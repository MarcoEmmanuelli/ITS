﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attributi
{
    [AttributeUsage(AttributeTargets.All)]
    public class Autore : System.Attribute
    {
        private string Nome;

        public Autore(string n)
        {
            Nome = n;
        }

        public string GetNome()
        {
            return Nome;
        }
    }
}
