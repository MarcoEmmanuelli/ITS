﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Attributi
{

    [Autore("Pippo")]
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Metodo1();
            Metodo2();
        }

        [Obsolete("usare il Metodo2")]
        private void Metodo1()
        {
            MessageBox.Show("Metodo1");
        }

        [Autore("Alberto Venditti")]
        private void Metodo2()
        {
            MessageBox.Show("Metodo2");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Attribute[] Att =
                Attribute.GetCustomAttributes(
                    this.GetType());

            foreach(Attribute a in Att)
            {
                if (a is Autore)
                    textBox1.Text += ((Autore)a).GetNome() +
                        "\r\n";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MethodInfo[] Met =
                this.GetType().GetMethods(BindingFlags.NonPublic |
                BindingFlags.Instance);

            foreach (MethodInfo m in Met)
                textBox1.Text += m.Name + "\r\n";
        }
    }
}
