﻿namespace LibraryImageLoaderCS
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            this.btnFromFile = new System.Windows.Forms.Button();
            this.btnReduceTo = new System.Windows.Forms.Button();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnRotate = new System.Windows.Forms.Button();
            this.lblCurrentSize = new System.Windows.Forms.Label();
            this.btnReduce = new System.Windows.Forms.Button();
            this.picPhoto = new System.Windows.Forms.PictureBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.btnLoad = new System.Windows.Forms.Button();
            this.lblName = new System.Windows.Forms.Label();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.dlgOpen = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.picPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // btnFromFile
            // 
            this.btnFromFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFromFile.Location = new System.Drawing.Point(508, 152);
            this.btnFromFile.Name = "btnFromFile";
            this.btnFromFile.Size = new System.Drawing.Size(120, 24);
            this.btnFromFile.TabIndex = 32;
            this.btnFromFile.Text = "Load from File";
            this.btnFromFile.Click += new System.EventHandler(this.btnFromFile_Click);
            // 
            // btnReduceTo
            // 
            this.btnReduceTo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReduceTo.Location = new System.Drawing.Point(508, 248);
            this.btnReduceTo.Name = "btnReduceTo";
            this.btnReduceTo.Size = new System.Drawing.Size(120, 24);
            this.btnReduceTo.TabIndex = 31;
            this.btnReduceTo.Text = "&Reduce to 120x160";
            this.btnReduceTo.Click += new System.EventHandler(this.ReduceTo_Click);
            // 
            // btnConvert
            // 
            this.btnConvert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConvert.Location = new System.Drawing.Point(508, 184);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(120, 24);
            this.btnConvert.TabIndex = 30;
            this.btnConvert.Text = "Convert to JPG";
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(524, 108);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 24);
            this.btnSave.TabIndex = 29;
            this.btnSave.Text = "Save to DB";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnRotate
            // 
            this.btnRotate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRotate.Location = new System.Drawing.Point(508, 280);
            this.btnRotate.Name = "btnRotate";
            this.btnRotate.Size = new System.Drawing.Size(120, 24);
            this.btnRotate.TabIndex = 28;
            this.btnRotate.Text = "Rotate";
            this.btnRotate.Click += new System.EventHandler(this.btnRotate_Click);
            // 
            // lblCurrentSize
            // 
            this.lblCurrentSize.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCurrentSize.Location = new System.Drawing.Point(12, 472);
            this.lblCurrentSize.Name = "lblCurrentSize";
            this.lblCurrentSize.Size = new System.Drawing.Size(480, 20);
            this.lblCurrentSize.TabIndex = 27;
            this.lblCurrentSize.Text = "<Current Size>";
            // 
            // btnReduce
            // 
            this.btnReduce.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReduce.Location = new System.Drawing.Point(508, 216);
            this.btnReduce.Name = "btnReduce";
            this.btnReduce.Size = new System.Drawing.Size(120, 24);
            this.btnReduce.TabIndex = 26;
            this.btnReduce.Text = "Reduce";
            this.btnReduce.Click += new System.EventHandler(this.btnReduce_Click);
            // 
            // picPhoto
            // 
            this.picPhoto.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picPhoto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picPhoto.Location = new System.Drawing.Point(12, 28);
            this.picPhoto.Name = "picPhoto";
            this.picPhoto.Size = new System.Drawing.Size(480, 440);
            this.picPhoto.TabIndex = 25;
            this.picPhoto.TabStop = false;
            this.picPhoto.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picPhoto_MouseDown);
            this.picPhoto.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picPhoto_MouseMove);
            // 
            // txtID
            // 
            this.txtID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtID.Location = new System.Drawing.Point(544, 44);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(68, 20);
            this.txtID.TabIndex = 23;
            // 
            // Label1
            // 
            this.Label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label1.Location = new System.Drawing.Point(524, 48);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(36, 16);
            this.Label1.TabIndex = 24;
            this.Label1.Text = "ID:";
            // 
            // btnLoad
            // 
            this.btnLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoad.Location = new System.Drawing.Point(524, 76);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(88, 24);
            this.btnLoad.TabIndex = 22;
            this.btnLoad.Text = "Load from DB";
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(12, 8);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(480, 23);
            this.lblName.TabIndex = 33;
            this.lblName.Text = "<name>";
            // 
            // Panel1
            // 
            this.Panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Panel1.Location = new System.Drawing.Point(508, 28);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(120, 116);
            this.Panel1.TabIndex = 34;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 501);
            this.Controls.Add(this.btnFromFile);
            this.Controls.Add(this.btnReduceTo);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnRotate);
            this.Controls.Add(this.lblCurrentSize);
            this.Controls.Add(this.btnReduce);
            this.Controls.Add(this.picPhoto);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.Panel1);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Library Image Loader";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    internal System.Windows.Forms.Button btnFromFile;
    internal System.Windows.Forms.Button btnReduceTo;
    internal System.Windows.Forms.Button btnConvert;
    internal System.Windows.Forms.Button btnSave;
    internal System.Windows.Forms.Button btnRotate;
    internal System.Windows.Forms.Label lblCurrentSize;
    internal System.Windows.Forms.Button btnReduce;
    internal System.Windows.Forms.PictureBox picPhoto;
    internal System.Windows.Forms.TextBox txtID;
    internal System.Windows.Forms.Label Label1;
    internal System.Windows.Forms.Button btnLoad;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.Panel Panel1;
    internal System.Windows.Forms.OpenFileDialog dlgOpen;
  }
}

