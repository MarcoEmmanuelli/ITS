﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Data.SqlClient;
using System.IO;

namespace LibraryImageLoaderCS
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    string ConnStr = "Server=.;database=Library;uid=sa;pwd=maggio";
    string ImageTable = "member";
    string ImageField = "photograph";
    string NameField = "CONVERT(varchar, member_no) + ' - ' + lastname + ' ' + firstname AS FullName";

    string IDfield = "member_no";

    int MultipleGet = 50;
    int CropW;
    int CropH;
    bool ProposingCrop = false;
    //3 / 3.5
    double ARatio = 120.0 / 160.0;

    Bitmap img;

    ImageFormat imgFormat;


    int[] LargestID;

    int CurrentIDindex;
    private void btnLoad_Click(System.Object sender, System.EventArgs e)
    {
      btnSave.Enabled = true;

      picPhoto.Image = null;
      Application.DoEvents();

      SqlConnection con = new SqlConnection(ConnStr);
      SqlDataAdapter da = new SqlDataAdapter("SELECT " + ImageField + "," + NameField + " FROM " + ImageTable + " WHERE " + IDfield + "=" + txtID.Text, con);
      SqlCommandBuilder cb = new SqlCommandBuilder(da);
      DataSet ds = new DataSet();

      try
      {
        this.Cursor = Cursors.WaitCursor;
        da.Fill(ds, "Images");
        this.Cursor = Cursors.Default;

        lblName.Text = ds.Tables["Images"].Rows[0][1].ToString();
        // FullName

        if (object.ReferenceEquals(ds.Tables["Images"].Rows[0][0], DBNull.Value))
        {
          lblCurrentSize.Text = "No picture";
        }
        else
        {
          byte[] imgData = (byte[])ds.Tables["Images"].Rows[0][ImageField];


          img = (Bitmap)Image.FromStream(new MemoryStream(imgData));
          imgFormat = img.RawFormat;
          picPhoto.Image = img;
          lblCurrentSize.Text = "Current Size: " + imgData.GetUpperBound(0) / 1024 + "Kb (" + img.Width + "x" + img.Height + ") [" + img.Width / img.Height + "]";
        }

      }
      catch (Exception ex)
      {
        lblCurrentSize.Text = "Error";
      }

    }


    private void btnReduce_Click(System.Object sender, System.EventArgs e)
    {
      btnSave.Enabled = true;
      Reduce(0.8);
    }

    private void Reduce(double factor)
    {
      img = new Bitmap(img, new Size((int)(img.Size.Width * factor),(int)(img.Size.Height * factor)));
      picPhoto.Image = img;
      MemoryStream ms = new MemoryStream();
      img.Save(ms, ImageFormat.Jpeg);
      lblCurrentSize.Text = "Current Size: " + ms.Length / 1024 + "Kb (" + img.Width + "x" + img.Height + ") [" + img.Width / img.Height + "]";
    }

    private void btnRotate_Click(System.Object sender, System.EventArgs e)
    {
      btnSave.Enabled = true;

      img.RotateFlip(RotateFlipType.Rotate90FlipNone);
      picPhoto.Image = img;
      //lblCurrentSize.Text = "Current Size: " & UBound(imgData) \ 1024 & "Kb (" & img.Width & "x" & img.Height & ") [" & img.Width / img.Height & "]"
    }


    private void btnSave_Click(System.Object sender, System.EventArgs e)
    {
      if (string.IsNullOrEmpty(txtID.Text))
        return;
      string IDrecord = txtID.Text;
      SqlConnection con = new SqlConnection(ConnStr);
      SqlDataAdapter da = new SqlDataAdapter("SELECT " + IDfield + ", " + ImageField + " FROM " + ImageTable + " WHERE " + IDfield + "='" + IDrecord + "'", con);
      SqlCommandBuilder cb = new SqlCommandBuilder(da);
      DataSet ds = new DataSet();
      da.MissingSchemaAction = MissingSchemaAction.AddWithKey;

      MemoryStream ms = new MemoryStream();
      img.Save(ms, ImageFormat.Jpeg);
      byte[] imgData = new byte[ms.Length];
      ms.Position = 0;
      ms.Read(imgData, 0, (int)ms.Length);

      da.Fill(ds, "Images");
      DataRow myRow = default(DataRow);
      myRow = ds.Tables["Images"].Rows[0];
      myRow[ImageField] = imgData;
      da.Update(ds, "Images");

      //    SaveTempFile(imgData)

      //btnSave.Enabled = False
      MessageBox.Show("Image saved.");
    }

    private void SaveTempFile(byte[] imgData)
    {
      FileStream fs = new FileStream("temp.jpg", FileMode.Create, FileAccess.Write);
      fs.Write(imgData, 0, imgData.GetUpperBound(0));
      fs.Close();
    }

    private void btnConvert_Click(System.Object sender, System.EventArgs e)
    {
      btnSave.Enabled = true;
      Reduce(1);
    }



    private void ReduceTo_Click(System.Object sender, System.EventArgs e)
    {
      btnSave.Enabled = true;
      img = new Bitmap(img, new Size(120, 160));
      picPhoto.Image = img;
      MemoryStream ms = new MemoryStream();
      img.Save(ms, ImageFormat.Jpeg);
      lblCurrentSize.Text = "Current Size: " + ms.Length / 1024 + "Kb (" + img.Width + "x" + img.Height + ") [" + img.Width / img.Height + "]";
    }

    private int GetImageKb()
    {
      MemoryStream ms = new MemoryStream();
      img.Save(ms, ImageFormat.Jpeg);
      return (int)(ms.Length / 1024);
    }

    private void btnFromFile_Click(System.Object sender, System.EventArgs e)
    {
      dlgOpen.Filter = "JPG image files (*.jpg)|*.jpg";
      dlgOpen.Multiselect = false;
      if (dlgOpen.ShowDialog() == DialogResult.Cancel)
        return;
      string Filename = dlgOpen.FileName;

      FileStream fs = new FileStream(Filename, FileMode.Open, FileAccess.Read);
      byte[] imgData = new byte[fs.Length + 1];
      fs.Read(imgData, 0, (int)fs.Length);
      fs.Close();

      try
      {
        img = (Bitmap)Image.FromStream(new MemoryStream(imgData));
        imgFormat = img.RawFormat;
        picPhoto.Image = img;
        lblCurrentSize.Text = "Current Size: " + imgData.GetUpperBound(0) / 1024 + "Kb (" + img.Width + "x" + img.Height + ") [" + img.Width / img.Height + "]";
      }
      catch
      {
        lblCurrentSize.Text = "Error";
      }
    }

    private void Log(string logMessage)
    {
      StreamWriter w = File.AppendText(Application.StartupPath + "\\LogFile.txt");
      w.WriteLine("{0}", logMessage);
      w.Flush();
      w.Close();
    }

    private void picPhoto_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
    {
      if (img == null)
        return;

      int x = e.X;
      int y = e.Y;

      if (ProposingCrop)
      {
        switch (e.Button)
        {
          case MouseButtons.Left:
            CropW = (int)(CropW * 0.9);
            CropH = (int)(CropH * 0.9);
            break;
          case MouseButtons.Right:
            if (MessageBox.Show("Do you want to Crop?", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
              Bitmap clip = default(Bitmap);
              clip = img.Clone(new RectangleF(x, y, Math.Min(CropW, img.Width - x), Math.Min(CropH, img.Height - y)), PixelFormat.Format32bppArgb);
              img = clip;
            }
            picPhoto.Image = img;
            break;
          //lblCurrentSize.Text = "Current Size: " & UBound(imgData) \ 1024 & "Kb (" & img.Width & "x" & img.Height & ") [" & img.Width / img.Height & "]"
        }
      }

      if (!ProposingCrop)
      {
        ProposingCrop = true;
        if (img.Height * ARatio > img.Width)
        {
          CropW = img.Width;
          CropH = (int)(img.Width / ARatio);
        }
        else
        {
          CropH = img.Height;
          CropW = (int)(img.Height * ARatio);
        }
        Image proposedCrop=null;
        Graphics g =null;
        try
        {
          proposedCrop = (Image)img.Clone();
          g = Graphics.FromImage(proposedCrop);
        }
        catch
        {
          Reduce(1);
          proposedCrop = (Image)img.Clone();
          g = Graphics.FromImage(proposedCrop);
        }
        finally
        {
          g.DrawRectangle(new Pen(Color.Yellow, 2), x, y, CropW, CropH);
          picPhoto.Image = proposedCrop;
        }
      }

    }

    private void picPhoto_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
    {
      int x = e.X;
      int y = e.Y;

      if (ProposingCrop)
      {
        Image proposedCrop = default(Image);
        Graphics g = default(Graphics);
        try
        {
          proposedCrop = (Image)img.Clone();
          g = Graphics.FromImage(proposedCrop);
        }
        catch
        {
          Reduce(1);
          proposedCrop = (Image)img.Clone();
          g = Graphics.FromImage(proposedCrop);
        }
        finally
        {
          g.DrawRectangle(new Pen(Color.Yellow, 2), x, y, CropW, CropH);
          picPhoto.Image = proposedCrop;
        }
      }
    }

    private void Form1_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
    {
      if (ProposingCrop)
      {
        if (e.KeyCode == Keys.Escape)
        {
          picPhoto.Image = img;
          ProposingCrop = false;
        }
      }
    }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
