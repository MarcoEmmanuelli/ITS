﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoria
{
  class Program
  {
    static void Main(string[] args)
    {
            //RedFish rf = new RedFish();
            //rf.Breath();
            //Console.WriteLine(rf.ToString());


            //Dog t = new Dog();
            //t.Breath();
            //t.Talk();
            //Console.WriteLine(t.ToString());

            //Basset b = new Basset();
            //b.Breath();
            //b.Breath(3);
            //b.Talk();
            //Console.WriteLine(b.ToString());


            List<Animal> lista = new List<Animal>();

            Dog lassie = new Dog();
            lista.Add(lassie);

            RedFish f = new RedFish();
            lista.Add(f);

            Turkey t = new Turkey();
            lista.Add(t);

            lista.Add(new Basset());

            foreach(Animal a in lista)
            {
                a.Breath();
                //if(a is Dog)
                //  (a as Dog).Talk();

                //Dog x = (a as Dog);
                //if (x != null)
                //    x.Talk();

                //Dog y = (Dog)a;

                //if ((a as Dog) != null)
                //    (a as Dog).Talk();

                if(a.GetType()==typeof(Dog))
                    (a as Dog).Talk();

            }

            //Basset b = new Basset();
            //Dog d = b;
            //Animal an = b;
            //Animal an1 = d;
            //object o = b;

            //b.Talk();
            //d.Talk();
            //an.Breath();
            //(o as Animal).Breath();

            //b.SecondName="Pippo";
            //Console.WriteLine((d as Basset).SecondName);
            //(an1 as Basset).SecondName = "Pluto";
            //Console.WriteLine((an1 as Basset).SecondName);

            Dog d1 = new Dog();
            Dog d2 = new Dog();
            Dog d3 = d1;

            if (d1 == d2)
                Console.WriteLine("d1==d2");
            else
                Console.WriteLine("d1!=d2");

            if (d1 == d3)
                Console.WriteLine("d1==d3");
            else
                Console.WriteLine("d1!=d3");


            Console.ReadLine();
    }
  }
}
