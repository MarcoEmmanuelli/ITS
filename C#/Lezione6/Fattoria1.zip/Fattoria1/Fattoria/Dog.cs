﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoria
{
    class Dog : Animal
    {
        public Dog()
        {
            LegsNumber = 4;
            AnimalFamily = Family.Mammals;
            Name = "Cane";
        }

        public void Talk()
        {
            Console.WriteLine("BAU!");
        }
        public override void Breath()
        {
            Console.WriteLine(Name + " bau-bau-eggiando!");
        }

        public override string ToString()
        {
            return Name + " " + Legs.ToString();
        }
    }
}
