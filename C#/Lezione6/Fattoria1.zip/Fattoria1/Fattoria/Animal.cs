﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoria
{
  abstract class Animal //: System.Object
  {
    public string Name;
    public Family AnimalFamily;
    protected int LegsNumber;

    public int Legs
    {
      get
      {
        return LegsNumber;
      }
    }


    public abstract void Breath();

  }

  public enum Family 
  {
    Mammals,
    Birds,
    Fishes
  }

}
