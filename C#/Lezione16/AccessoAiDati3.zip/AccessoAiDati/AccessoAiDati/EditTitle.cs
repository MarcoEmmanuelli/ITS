﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccessoAiDati
{
    public partial class EditTitle : Form
    {
        public EditTitle()
        {
            InitializeComponent();
        }

        public int TitleNo = 0;
        public string Mode = "Edit";   // "Edit" oppure "New"

        private void EditTitle_Load(object sender, EventArgs e)
        {
            if (Mode == "Edit")
            {
                this.Text = "Modifica Libro";
                string SQLstr = "SELECT * FROM title" +
                    " WHERE title_no=" + TitleNo.ToString();
                DataTable dt = Util.GetDataTable(SQLstr);
                DataRow dr = dt.Rows[0];
                txtAutore.Text = dt.Rows[0]["author"].ToString();
                txtTitolo.Text = dr["title"].ToString();
                txtRiassunto.Text = dr["synopsis"].ToString();
            }
            else
                this.Text = "Nuovo Libro";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (Mode == "Edit")
            {
                string SQLstr = "UPDATE title SET ";
                SQLstr += " author=N'" +
                    txtAutore.Text.Replace("'", "''") + "',";
                SQLstr += " title=N'" +
                    txtTitolo.Text.Replace("'", "''") + "',";
                SQLstr += " synopsis=N'" +
                    txtRiassunto.Text.Replace("'", "''") + "'";
                SQLstr += " WHERE title_no=" + TitleNo.ToString();

                Util.ExecuteCommand(SQLstr);
            }
            else
            {
                string SQLstr = "INSERT title ";
                SQLstr+=" (author, title, synopsis) VALUES (";
                SQLstr += "N'" +
                    txtAutore.Text.Replace("'", "''") + "',";
                SQLstr += " N'" +
                    txtTitolo.Text.Replace("'", "''") + "',";
                SQLstr += " N'" +
                    txtRiassunto.Text.Replace("'", "''") + "');";
                SQLstr += " SELECT @@IDENTITY";

                TitleNo=Util.ExecuteCommand2(SQLstr);
            }
            this.DialogResult = DialogResult.OK;
        }
    }
}
