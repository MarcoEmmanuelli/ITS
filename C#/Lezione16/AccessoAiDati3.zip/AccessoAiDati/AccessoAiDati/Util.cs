﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessoAiDati
{
    static class Util
    {
        static string ConnStr = "server=BSI-2123-31;database=Library;uid=sa;pwd=maggio;Application Name=cippirimerlo";

        static public DataTable GetDataTable(string SQLstr)
        {
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(SQLstr, ConnStr);
            da.Fill(dt);
            return dt;
        }

        static public int ExecuteCommand(string SQLstr)
        {
            SqlConnection cnn = new SqlConnection(ConnStr);
            SqlCommand cmd = cnn.CreateCommand();
            cmd.CommandText = SQLstr;
            cnn.Open();
            int righe=cmd.ExecuteNonQuery();
            cnn.Close();
            return righe;
        }

        static public int ExecuteCommand2(string SQLstr)
        {
            SqlConnection cnn = new SqlConnection(ConnStr);
            SqlCommand cmd = cnn.CreateCommand();
            cmd.CommandText = SQLstr;
            cnn.Open();
            int ID = int.Parse(cmd.ExecuteScalar().ToString());
            cnn.Close();
            return ID;
        }
    }
}
