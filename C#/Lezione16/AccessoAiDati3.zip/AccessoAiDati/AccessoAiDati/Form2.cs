﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccessoAiDati
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        private void btnLeggi_Click(object sender, EventArgs e)
        {
            CaricaLista(0);
        }


        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgTitles.SelectedRows.Count != 1)
            {
                MessageBox.Show("Selezionare una e una sola riga.");
                return;
            }

            DataRowView dr = ((DataRowView)dgTitles.SelectedRows[0].DataBoundItem);
            EditTitle f = new EditTitle();
            f.TitleNo = (int)dr["title_no"];
            if(f.ShowDialog()==DialogResult.OK)
                CaricaLista(f.TitleNo);
        }

        private void CaricaLista(int tNum)
        {
            string SQLstr = "SELECT * FROM title";
            dgTitles.DataSource = Util.GetDataTable(SQLstr);

            //System.Diagnostics.Debug.WriteLine(
            //    dgTitles.SelectedRows.Count);
            
            dgTitles.ClearSelection();

            if (tNum>0)
            {
                foreach(DataGridViewRow r in dgTitles.Rows)
                    if((int)((DataRowView)r.DataBoundItem)["title_no"]
                        ==tNum)
                    {
                       
                        r.Selected = true;
                        dgTitles.FirstDisplayedScrollingRowIndex =
                            dgTitles.SelectedRows[0].Index;
                       
                        break;
                    }
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            EditTitle f = new EditTitle();
            f.Mode="New";
            if (f.ShowDialog() == DialogResult.OK)
                CaricaLista(f.TitleNo);
        }

        private void btnCerca_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow r in dgTitles.Rows)
            {
                object c= ((DataRowView)r.DataBoundItem)["author"];
                if (c != null && c!= DBNull.Value &&
                    c.ToString().Contains(txtCerca.Text)
                    )
                {
                    r.Selected = true;
                }

            }
        }
    }
}
