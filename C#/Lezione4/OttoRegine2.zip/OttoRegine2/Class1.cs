using System;

namespace OttoRegine2
{
  /// <summary>
  ///	Rompicapo delle OTTO REGINE
  /// </summary>
  class Class1
  {
    // Ci sono 8 regine, una per colonna
    // Nell'array, di ciascuna regina memorizzo in che riga viene piazzata
    static int[] queen = new int[8];

    static byte[] row = new byte[8];
    static byte[] dia = new byte[15];
    static byte[] rdia = new byte[15];

    static void Main(string[] args)
    {
      int i, j;
      if (muovi(0))
      {
        for (i = 0; i < 8; i++)
        {
          for (j = 0; j < 8; j++)
            if (queen[i] == j)
              Console.Write("X ");
            else
              Console.Write("O ");
          Console.WriteLine();
        }
      }
      Console.ReadLine();
    }

    static bool muovi(int n)
    {
      int i;
      if (n == 8)     // posizionate tutte e 8 le regine
        return (true);
      for (i = 0; i < 8; i++)
        if (row[i] == 0 && dia[n + i] == 0 && rdia[n - i + 7] == 0)
        {
          setqueen(n, i);
          if (muovi(n + 1))
            return (true);
          removequeen(n, i);
        }
      return (false);
    }

    static void setqueen(int colonna, int riga)
    {
      queen[colonna] = riga;
      row[riga] = dia[colonna + riga] = rdia[7 + colonna - riga] = 255;
    }

    static void removequeen(int colonna, int riga)
    {
      queen[colonna] = row[riga] = dia[colonna + riga] = rdia[7 + colonna - riga] = 0;
    }
  }
}
