﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HorsePuzzle
{
  class Program
  {
    // Nota: su una scacchiera 4x4 non c'è soluzione
    const int BoardSize=8;

    // Offset per le 8 possibili mosse del cavallo
    static int[,] Offset = new int[8, 2] { { 2, 1 }, { 1, 2 }, { -1, 2 }, { -2, 1 }, { -2, -1 }, { -1, -2 }, { 1, -2 }, { 2, -1 } };

    // sequenza di mosse alternativa
    //static int[,] Offset = new int[8, 2] { { 1, 2 }, { 2, 1 }, { 2, -1 }, { 1, -2 }, { -1, -2 }, { -2, -1 }, { -2, -1 }, { -1, 2 } };
      

    //static int TriedMoves = 0;   // Contatore delle mosse "tentate"
    static void Main(string[] args)
    {
      int[,] Board = new int[BoardSize, BoardSize];
      
      Position InitialPosition;
      InitialPosition.row = 0;
      InitialPosition.col = 0;

      int DoneMoves = 0;
      //TriedMoves = 0;

      Position CurrentPosition=InitialPosition;
      MarkMove(Board, CurrentPosition, ref DoneMoves);

      DateTime dtStart = DateTime.Now;
      MoveHorse(Board, CurrentPosition, DoneMoves);
      DateTime dtFinish = DateTime.Now;

      ShowBoard(Board);

      Console.WriteLine("Elapsed time: " + dtFinish.Subtract(dtStart).ToString());
      //Console.WriteLine("Tried moves: " + TriedMoves.ToString());
      Console.ReadLine();
    }

    private static void ShowBoard(int[,] Board)
    {
      Console.Clear();
      Console.WriteLine();  // Una riga di spaziatura iniziale
      for (int r = 0; r < BoardSize; r++)
      {
        Console.Write("  ");  // Un paio di caratteri di spaziatura a inizio riga
        for (int c = 0; c < BoardSize; c++)
        {
          if (Board[r, c]!=0)
            Console.Write("{0:D2}  ", Board[r, c]);
          else
            Console.Write("    ");
        }
        Console.WriteLine();
        Console.WriteLine();
      }
    }

    private static void MarkMove(int[,] Board, Position MovePosition, ref int DoneMoves)
    {
      DoneMoves++;
      Board[MovePosition.row, MovePosition.col] = DoneMoves;
    }

    private static void UnmarkMove(int[,] Board, Position MovePosition, ref int DoneMoves)
    {
      Board[MovePosition.row, MovePosition.col] = 0;
      DoneMoves--;
    }

    private static bool MoveHorse(int[,] Board, Position CurrentPosition, int DoneMoves)
    {
      if (DoneMoves == BoardSize * BoardSize)
        return true;

      for (int i = 0; i < 8; i++)
      {
        Position NextPosition = CurrentPosition;
        NextPosition.col += Offset[i,0];
        NextPosition.row += Offset[i,1];
        if (IsValid(Board, NextPosition))
        {
          MarkMove(Board, NextPosition, ref DoneMoves);
          if (MoveHorse(Board, NextPosition, DoneMoves))
            return true;
          UnmarkMove(Board, NextPosition, ref DoneMoves);
          //TriedMoves++;   // Conta le mosse provate su caselle vuote
        }
        //TriedMoves++;   // Conta tutte le mosse provate (anche fuori scacchiera o su caselle non vuote)
      }

      //ShowBoard(Board);
      //Console.ReadLine();

      return false;
    }

    private static bool IsValid(int[,] Board, Position ProposedPosition)
    {
      if (ProposedPosition.row < 0 || ProposedPosition.row >= BoardSize || 
        ProposedPosition.col < 0 || ProposedPosition.col >= BoardSize)
        return false;
      if (Board[ProposedPosition.row, ProposedPosition.col] != 0)
        return false;
      return true;
    }
    
    struct Position
    {
      public int row;
      public int col;
    }
  }
}
