﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccessoAiDati
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            e.Cancel = true;
        }

        SqlDataAdapter da;
        DataTable dt;
        private void btnLeggi_Click(object sender, EventArgs e)
        {
            string ConnStr = "server=BSI-2123-31;database=Library;uid=sa;pwd=maggio;Application Name=cippirimerlo";
            string SQLstr = "SELECT * FROM title";
            dt = new DataTable();
            da = new SqlDataAdapter(SQLstr, ConnStr);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Fill(dt);
            dgTitles.DataSource = dt;
        }

        private void btnAggiorna_Click(object sender, EventArgs e)
        {
            da.Update(dt);
        }
    }
}
