﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccessoAiDati
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ConnStr = "server=BSI-2123-31;database=Library;uid=sa;pwd=maggio;Application Name=cippirimerlo";
            SqlConnection cnn = new SqlConnection();
            cnn.ConnectionString = ConnStr;

            //SqlConnection cnn = new SqlConnection(ConnStr);

            cnn.Open();

            SqlCommand cmd = cnn.CreateCommand();
            cmd.CommandText = "SELECT TOP 10 * FROM member; ";
            cmd.CommandText += "SELECT TOP 10 * FROM juvenile; ";

            SqlDataReader dr = cmd.ExecuteReader();

            StringBuilder sb = new StringBuilder();
            int resultset = 0;
            do
            {
                while (dr.Read())
                {
                    sb.Append(dr.FieldCount.ToString() + " - ");
                    if (resultset == 0)
                        sb.Append(dr["lastname"].ToString());
                    else
                        sb.Append(dr["birth_date"].ToString());

                    sb.Append("\r\n");

                    //textBox1.Text += dr["lastname"].ToString();
                    //textBox1.Text += "\r\n";
                    //Application.DoEvents();
                }
                resultset++;
            }
            while (dr.NextResult());

            textBox1.Text = sb.ToString();
            dr.Close();
            cnn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ConnStr = "server=BSI-2123-31;database=Library;uid=sa;pwd=maggio";
            SqlConnection cnn = new SqlConnection();
            cnn.ConnectionString = ConnStr;
            cnn.Open();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string ConnStr = "server=BSI-2123-31;database=Library;uid=sa;pwd=maggio;Application Name=cippirimerlo";
            SqlConnection cnn = new SqlConnection(ConnStr);
            SqlCommand cmd = cnn.CreateCommand();
            cmd.CommandText = "INSERT title (title,author) VALUES (";
            cmd.CommandText += "'" + txtTitolo.Text.Replace("'","''") + "',";
            cmd.CommandText += "'" + txtAutore.Text.Replace("'", "''") + "')";
            cnn.Open();
            int records=cmd.ExecuteNonQuery();
            cnn.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = CreaComando("SELECT COUNT(*) FROM title");
            cmd.Connection.Open();
            int records = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();
            textBox1.Text = records.ToString();
        }

        private SqlCommand CreaComando(string cmdtxt)
        {
            string ConnStr = "server=BSI-2123-31;database=Library;uid=sa;pwd=maggio;Application Name=cippirimerlo";
            SqlConnection cnn = new SqlConnection(ConnStr);
            SqlCommand cmd = cnn.CreateCommand();
            cmd.CommandText = cmdtxt;
            return cmd;
        }

        Form2 f=null;
        private void button5_Click(object sender, EventArgs e)
        {
            if (f == null)
            {
                f = new Form2();               
            }
            f.Show();
            f.Focus();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtTitolo.Focus();
        }
    }
}
