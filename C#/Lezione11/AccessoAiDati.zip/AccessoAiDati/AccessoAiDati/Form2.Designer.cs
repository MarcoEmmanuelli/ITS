﻿
namespace AccessoAiDati
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgTitles = new System.Windows.Forms.DataGridView();
            this.btnLeggi = new System.Windows.Forms.Button();
            this.TitleNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Autore = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Titolo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Synopsis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAggiorna = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgTitles)).BeginInit();
            this.SuspendLayout();
            // 
            // dgTitles
            // 
            this.dgTitles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgTitles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTitles.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TitleNo,
            this.Autore,
            this.Titolo,
            this.Synopsis});
            this.dgTitles.Location = new System.Drawing.Point(12, 92);
            this.dgTitles.Name = "dgTitles";
            this.dgTitles.Size = new System.Drawing.Size(885, 364);
            this.dgTitles.TabIndex = 0;
            // 
            // btnLeggi
            // 
            this.btnLeggi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeggi.Location = new System.Drawing.Point(13, 27);
            this.btnLeggi.Name = "btnLeggi";
            this.btnLeggi.Size = new System.Drawing.Size(116, 49);
            this.btnLeggi.TabIndex = 1;
            this.btnLeggi.Text = "LEGGI";
            this.btnLeggi.UseVisualStyleBackColor = true;
            this.btnLeggi.Click += new System.EventHandler(this.btnLeggi_Click);
            // 
            // TitleNo
            // 
            this.TitleNo.DataPropertyName = "title_no";
            this.TitleNo.Frozen = true;
            this.TitleNo.HeaderText = "TitleNo";
            this.TitleNo.Name = "TitleNo";
            this.TitleNo.Visible = false;
            // 
            // Autore
            // 
            this.Autore.DataPropertyName = "author";
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Lime;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Yellow;
            this.Autore.DefaultCellStyle = dataGridViewCellStyle1;
            this.Autore.Frozen = true;
            this.Autore.HeaderText = "Autore";
            this.Autore.Name = "Autore";
            // 
            // Titolo
            // 
            this.Titolo.DataPropertyName = "title";
            this.Titolo.HeaderText = "Titolo Libro";
            this.Titolo.Name = "Titolo";
            // 
            // Synopsis
            // 
            this.Synopsis.DataPropertyName = "synopsis";
            this.Synopsis.HeaderText = "Synopsis";
            this.Synopsis.Name = "Synopsis";
            this.Synopsis.Visible = false;
            // 
            // btnAggiorna
            // 
            this.btnAggiorna.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAggiorna.Location = new System.Drawing.Point(154, 27);
            this.btnAggiorna.Name = "btnAggiorna";
            this.btnAggiorna.Size = new System.Drawing.Size(150, 49);
            this.btnAggiorna.TabIndex = 2;
            this.btnAggiorna.Text = "AGGIORNA";
            this.btnAggiorna.UseVisualStyleBackColor = true;
            this.btnAggiorna.Click += new System.EventHandler(this.btnAggiorna_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 482);
            this.Controls.Add(this.btnAggiorna);
            this.Controls.Add(this.btnLeggi);
            this.Controls.Add(this.dgTitles);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgTitles)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgTitles;
        private System.Windows.Forms.Button btnLeggi;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Autore;
        private System.Windows.Forms.DataGridViewTextBoxColumn Titolo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Synopsis;
        private System.Windows.Forms.Button btnAggiorna;
    }
}