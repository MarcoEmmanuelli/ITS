using System;
using System.Collections;

class MainClass
{
	// Delegate must match signature and ret type with impersoned functions
	delegate bool IsGreaterThan(int first, int second);

  static bool Compare(int first, int second)
  {
    return first > second;
  }

  static bool CompareABS(int first, int second)
  {
    return (first >= 0 ? first : -first) > (second >= 0 ? second : -second);
  }

  static void ShowResult(int first, int second, IsGreaterThan Greater)
  {
    Console.WriteLine("Comparing {0} and {1}: {2}", first, second, Greater(first, second));
  }

  static void Main(string[] args)
	{
		ShowResult(-10, 2, Compare);		
		ShowResult(-10, 2, CompareABS);	
		Console.ReadLine();

    // A delegate is a TYPE: you can instantiate it
    ShowResult(-10, 2, new IsGreaterThan(Compare));   // First delegate created on Compare
    ShowResult(-10, 2, new IsGreaterThan(CompareABS));  // Second one create on CompareABS
    Console.ReadLine();
  }

}