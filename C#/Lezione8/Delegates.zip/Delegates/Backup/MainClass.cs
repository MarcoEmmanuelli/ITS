using System;
using System.Collections;

class MainClass
{
	// Delegate must match signature and ret type with impersoned functions
	delegate bool IsGreaterThan(int first, int second);

	static void Main(string[] args)
	{
		ShowResult(-10, 2, new IsGreaterThan(Compare));		// First delegate created on Compare
		ShowResult(-10, 2, new IsGreaterThan(CompareABS));	// Second one create on CompareABS
		Console.ReadLine();

		// Let's try to build a list of delegates, so that we can iterate through them
		ArrayList arCompMethods = new ArrayList();

		arCompMethods.Add(new IsGreaterThan(Compare));
		arCompMethods.Add(new IsGreaterThan(CompareABS));

		// Oops, this one is an intruder! (A boxed int).
		arCompMethods.Add(1);

		foreach(object o in arCompMethods)
		{
			// Smart type checking, safe function calling. We've avoided the nasty boxed int.
			if (o is IsGreaterThan)
				ShowResult(-10, 2, o as IsGreaterThan);
		}
		Console.ReadLine();
	}

	static void ShowResult(int first, int second, IsGreaterThan Greater)
	{
		Console.WriteLine("{0}", Greater(first, second));
	}

	static bool Compare(int first, int second)
	{
		return first > second;
	}

	static bool CompareABS(int first, int second)
	{
		return (first >= 0 ? first : -first) > (second >= 0 ? second : -second);
	}
}