﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArraySort
{
  class Program
  {
    static void Main(string[] args)
    {
      // declaring and initializing the array
      int[] arr = new int[] { 1, 9, 6, 7, 5, 8 };

      // Sort the arr from last to first.
      Array.Sort(arr, new MyComparison());

      // print all element of array
      foreach (int value in arr)
      {
        Console.Write(value + " ");
      }
      Console.ReadLine();
    }
  }
  // Custom comparison
  class MyComparison : IComparer<int>
  {
    public int Compare(int x, int y)
    {
      return y.CompareTo(x);
    }
  }

}
