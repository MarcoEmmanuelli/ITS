using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ControlArray
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button cmdCtrlArray;
		private System.Windows.Forms.TextBox txtHowMany;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdCtrlArray = new System.Windows.Forms.Button();
			this.txtHowMany = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// cmdCtrlArray
			// 
			this.cmdCtrlArray.Location = new System.Drawing.Point(16, 24);
			this.cmdCtrlArray.Name = "cmdCtrlArray";
			this.cmdCtrlArray.Size = new System.Drawing.Size(104, 23);
			this.cmdCtrlArray.TabIndex = 0;
			this.cmdCtrlArray.Text = "Crea pulsanti";
			this.cmdCtrlArray.Click += new System.EventHandler(this.cmdCtrlArray_Click);
			// 
			// txtHowMany
			// 
			this.txtHowMany.Location = new System.Drawing.Point(152, 24);
			this.txtHowMany.Name = "txtHowMany";
			this.txtHowMany.TabIndex = 1;
			this.txtHowMany.Text = "5";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.txtHowMany,
																		  this.cmdCtrlArray});
			this.Name = "Form1";
			this.Text = "\"Control Arrays\" in C#";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}



		System.Windows.Forms.Button cmdTemplate;

		private void cmdCtrlArray_Click(object sender, System.EventArgs e)
		{
			int i;
			for (i = 1; i <= Convert.ToInt32(txtHowMany.Text); i++)
			{
				// Creazione del controllo Button
				cmdTemplate = new System.Windows.Forms.Button();
				cmdTemplate.Location = new System.Drawing.Point(16 * i, 50 + 30 * i);
				cmdTemplate.Name = "cmdCustom" + i.ToString();
				cmdTemplate.Size = new System.Drawing.Size(112, 24);
				cmdTemplate.TabIndex = i;
				cmdTemplate.Text = "Pulsante Custom " + i.ToString();
				cmdTemplate.Visible = true;

				// Aggancio dell'event handler
				cmdTemplate.Click += new System.EventHandler(this.CustomButtonClick);

				// Aggiunta del controllo al Form
				this.Controls.Add(cmdTemplate);
			}
		}

		private void CustomButtonClick(System.Object sender, System.EventArgs e)
		{
			MessageBox.Show("Hai premuto il pulsante: " + (sender as Button).Name);
		}

	}
}
