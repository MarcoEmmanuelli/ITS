﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fibonacci
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Quanti? ");
      string s = Console.ReadLine();
      int quanti = int.Parse(s);

      try
      {
        int[] r = SerieFibonacci(quanti);
        for (int i = 0; i < quanti; i++)
          Console.Write("{0} ", r[i]);

        //// Variante col foreach()
        //foreach(int p in r)
        //    Console.Write("{0} ", p);

        //// Variante con scorrimento a ritroso
        //for (int i = quanti-1; i >=0; i--)
        //    Console.Write("{0} ", r[i]);

        //// Errato utilizzo degli indici di array
        //for (int i = quanti; i > 0; i--)
        //    Console.Write("{0} ", r[i]);
      }
      catch (OverflowException oe)
      {
        Console.WriteLine("Serie troppo lunga!");
        Console.WriteLine(oe.Message);
        Console.WriteLine(oe.StackTrace);
      }
      catch (DivideByZeroException db0e)
      {
        Console.WriteLine("Divisione per zero!");
      }
      //catch (Exception ex)
      //{
      //    Console.WriteLine("Errore non previsto");
      //    Console.WriteLine(ex.Message);
      //    Console.WriteLine(ex.ToString());
      //}
      finally
      {
      }
      Console.ReadLine();
    }

    // In questa versione, il metodo SerieFibonacci() non esegue output diretto
    // sulla Console, ma effettua il calcolo della serie restituendo il risultato
    // in un array
    static int[] SerieFibonacci(int q)
    {
      int[] res = new int[q];
      int ri = 0;

      int a = 0, b = 1, c = 0;
      //Console.Write("{0} {1} ", a, b);
      res[ri++] = a;
      res[ri++] = b;


      //Console.Write(a.ToString() + " " + b.ToString() + " ");

      //for (int i = 2; i < q; i++)
      //{
      //    c = a + b;
      //    Console.Write("{0} ", c);
      //    a = b;
      //    b = c;
      //}

      //int i = 2;
      //while (i < q)
      //{
      //    c = a + b;
      //    Console.Write("{0} ", c);
      //    a = b;
      //    b = c;
      //    i++;
      //}

      int i = 2;
      for (; i < q;)
      {
        c = a + b;
        //Console.Write("{0} ", c);
        res[ri++] = c;
        a = b;
        b = c;
        i++;
      }
      return res;
    }
  }
}
