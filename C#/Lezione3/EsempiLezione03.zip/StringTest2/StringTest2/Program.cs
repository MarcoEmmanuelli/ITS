﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringTest2
{
  class Program
  {
    static void Main(string[] args)
    {
      // Comparazione delle performance di accodamento stringhe
      // tra "string" e StringBuilder

      string s = "";
      DateTime Inizio = DateTime.Now;
      for (int i = 0; i < 50000; i++)
        s = s + "1234567890";
      DateTime Fine = DateTime.Now;

      TimeSpan Durata = Fine - Inizio;
      //TimeSpan Durata = Fine.Subtract(Inizio);
      Console.WriteLine(Durata.ToString());


      StringBuilder sb = new StringBuilder();
      Inizio = DateTime.Now;
      for (int i = 0; i < 50000; i++)
        sb.Append("1234567890");
      Fine = DateTime.Now;
      Durata = Fine - Inizio;
      Console.WriteLine(Durata);

      Console.ReadLine();
    }
  }
}
