﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringTest
{
  class Program
  {
    static void Main(string[] args)
    {
      string s1 = "Hello";
      string t1 = (string)s1.Clone();
      string t2 = s1;
      string t3 = string.Copy(s1);
      string t4 = "Hello";
      string t5 = "HELLO";

      Console.WriteLine("s1==t1: " + (s1 == t1).ToString());
      Console.WriteLine("s1.Equals(t1): " +
          (s1.Equals(t1)).ToString());
      Console.WriteLine("Object.ReferenceEquals(s1,t1): " +
          Object.ReferenceEquals(s1, t1).ToString());
      Console.WriteLine("Object.ReferenceEquals(s1,t2): " +
          Object.ReferenceEquals(s1, t2).ToString());
      Console.WriteLine("Object.ReferenceEquals(s1,t3): " +
          Object.ReferenceEquals(s1, t3).ToString());
      Console.WriteLine("Object.ReferenceEquals(s1,t4): " +
          Object.ReferenceEquals(s1, t4).ToString());


      Console.WriteLine("s1: " + s1);
      Console.WriteLine("t2: " + t2);
      Console.WriteLine("Object.ReferenceEquals(s1,t2): " +
        Object.ReferenceEquals(s1, t2).ToString());

      t2 += "x";   //  t2 = t2 + "x";

      Console.WriteLine("s1: " + s1);
      Console.WriteLine("t2: " + t2);
      Console.WriteLine("Object.ReferenceEquals(s1,t2): " +
       Object.ReferenceEquals(s1, t2).ToString());

      Console.ReadLine();
    }
  }
}
