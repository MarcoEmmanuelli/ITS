﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArray
{
  class Program
  {
    static void Main(string[] args)
    {
      // Esempio sintattico sul jagged array
      int[][] jArray = new int[2][];
      jArray[0] = new int[2] { 1, 2 };
      jArray[1] = new int[3] { 3, 4, 5 };
      Console.WriteLine(jArray[1][2]);

      // Alternativa matriciale
      int[,] kArray = new int[2, 3];
      kArray[0, 0] = 1;
      kArray[0, 1] = 2;
      kArray[1, 0] = 3;
      kArray[1, 1] = 4;
      kArray[1, 2] = 5;
      Console.WriteLine(kArray[1, 2]);
      Console.WriteLine(kArray.GetLowerBound(0));
      Console.WriteLine(kArray.GetUpperBound(0));
      Console.WriteLine(kArray.GetLowerBound(1));
      Console.WriteLine(kArray.GetUpperBound(1));
      Console.WriteLine(kArray.Length);

      Console.ReadLine();
    }
  }
}
