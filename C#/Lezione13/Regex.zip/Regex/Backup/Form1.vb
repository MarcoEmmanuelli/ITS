Imports System.Text.RegularExpressions

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtRegEx As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtText As System.Windows.Forms.TextBox
    Friend WithEvents lblMatch As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSQL As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblTableName As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtRegEx = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtText = New System.Windows.Forms.TextBox()
        Me.lblMatch = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtSQL = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTableName = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 23)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "RegEx:"
        '
        'txtRegEx
        '
        Me.txtRegEx.Location = New System.Drawing.Point(64, 40)
        Me.txtRegEx.Name = "txtRegEx"
        Me.txtRegEx.Size = New System.Drawing.Size(336, 20)
        Me.txtRegEx.TabIndex = 2
        Me.txtRegEx.Text = "href\s*=\s*(?:""""(?<1>[^""""]*)""""|(?<1>\S+))"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 23)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Text:"
        '
        'txtText
        '
        Me.txtText.Location = New System.Drawing.Point(64, 72)
        Me.txtText.Name = "txtText"
        Me.txtText.Size = New System.Drawing.Size(336, 20)
        Me.txtText.TabIndex = 4
        Me.txtText.Text = ""
        '
        'lblMatch
        '
        Me.lblMatch.Location = New System.Drawing.Point(64, 96)
        Me.lblMatch.Name = "lblMatch"
        Me.lblMatch.Size = New System.Drawing.Size(168, 16)
        Me.lblMatch.TabIndex = 5
        Me.lblMatch.Text = "NO MATCH"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(388, 23)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Sample 1: Validating an input text on a specified pattern"
        '
        'txtSQL
        '
        Me.txtSQL.Location = New System.Drawing.Point(64, 176)
        Me.txtSQL.Name = "txtSQL"
        Me.txtSQL.Size = New System.Drawing.Size(336, 20)
        Me.txtSQL.TabIndex = 8
        Me.txtSQL.Text = "SELECT * FROM authors WHERE au_lname='White'"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(16, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 23)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "SQL:"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(16, 148)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(388, 23)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Sample 2: Extracting the table name from a SELECT string"
        '
        'lblTableName
        '
        Me.lblTableName.Location = New System.Drawing.Point(64, 200)
        Me.lblTableName.Name = "lblTableName"
        Me.lblTableName.Size = New System.Drawing.Size(168, 16)
        Me.lblTableName.TabIndex = 10
        Me.lblTableName.Text = "NO MATCH"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(16, 200)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 23)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Table:"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 235)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label7, Me.lblTableName, Me.txtSQL, Me.Label4, Me.Label5, Me.lblMatch, Me.txtText, Me.Label2, Me.txtRegEx, Me.Label1, Me.Label3})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "RegularExpressions Sample"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim MyRegEx As RegEx

    Private Sub txtRegEx_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtRegEx.Leave
        MyRegEx = New Regex(txtRegEx.Text)
    End Sub

    Private Sub txtText_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtText.TextChanged
        If MyRegEx.IsMatch(txtText.Text) Then
            lblMatch.Text = "MATCH"
        Else
            lblMatch.Text = "NO MATCH"
        End If
    End Sub

    Private Sub txtSQL_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSQL.TextChanged
        Dim reFROM As New Regex("\s{1,}FROM\s{1,}")     ' stringa " FROM "
        Dim reTABLE As New Regex("[^ ]+")
        Dim mtFROM, mtTABLE As Match
        If reFROM.IsMatch(txtSQL.Text) Then
            mtFROM = reFROM.Match(txtSQL.Text)
            mtTABLE = reTABLE.Match(txtSQL.Text.Substring(mtFROM.Index + mtFROM.Length))
            lblTableName.Text = mtTABLE.Value
        Else
            lblTableName.Text = "NO MATCH"
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtSQL_TextChanged(Nothing, Nothing)
    End Sub

End Class
