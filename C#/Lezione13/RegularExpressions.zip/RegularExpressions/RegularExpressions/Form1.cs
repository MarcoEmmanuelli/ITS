﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegularExpressions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Regex re;
        private void btnCerca_Click(object sender, EventArgs e)
        {
            re = new Regex(txtRE.Text);
            if (re.IsMatch(txtTesto.Text))
            {
                foreach(Match m in re.Matches(txtTesto.Text))
                    MessageBox.Show("Pattern Trovato: "+
                        m.Value + " in posizione "+
                        m.Index);

            }
        }
    }
}
