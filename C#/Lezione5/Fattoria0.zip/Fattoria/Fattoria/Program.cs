﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoria
{
  // esempi/esperimenti sulle classi

  class Program
  {
    static void Main(string[] args)
    {
      Animal[] a = new Animal[3];         // esempio di array di oggetti
      a[0] = new Animal("Lassie", Family.Mammals, 4);
      a[0].Nickname = "Pippo";
      Console.WriteLine(a[0].Nickname);   // il nickname recepito è di soli 3 caratteri
      a[0].Codice = 12345;
      Console.WriteLine(a[0].Codice);     // il codice recepito è 123
      a[0].Codice = 75;
      Console.WriteLine(a[0].Codice);     // il codice recepito è 75
      a[0].Move();

      a[1] = new Animal("Snoopy", Family.Mammals, 4);
      a[1].Move();

      a[2] = new Animal("Johnny", Family.Fishes, 0);
      a[2].Move();


      Console.WriteLine(a[0].Name + ", " + a[1].Name + ", " + a[2].Name);
      Console.WriteLine(a[0].GetLegsNumber());
      Console.WriteLine(a[0].Legs);
      Console.WriteLine(a[0].AnimalFamily);
      Console.ReadLine();
    }
  }
}
