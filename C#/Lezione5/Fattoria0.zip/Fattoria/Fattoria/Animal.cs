﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fattoria
{
  class Animal
  {
    public string Name;             // esempio di field
    public Family AnimalFamily;     // esempio di uso di tipo enumerato
    private int LegsNumber;
    private string _Nickname;
    private int _Codice;

    public long Codice
    {
      get
      {
        return _Codice;
      }
      set
      {
        // si vogliono accettare solo valori da 0 a 999
        // se il numero è >=1000, si prendono le prime 3 cifre
        string s = value.ToString();

        _Codice = int.Parse(s.Substring(0,
            s.Length >= 3 ? 3 : s.Length));
      }

    }
    public string Nickname
    {
      get
      {
        return _Nickname;
      }
      set
      {
        // il nickname deve essere al massimo di 3 caratteri
        if (value.Length > 3)
          _Nickname = value.Substring(0, 3);
        else
          _Nickname = value;
      }
    }

    public int Legs
    {
      get
      {
        return LegsNumber;
      }
    }

    public int GetLegsNumber()
    {
      return LegsNumber;
    }

    public void Move()
    {
      Console.WriteLine(Name + " moving...");
    }


    // costruttore standard
    public Animal()
    { }

    // costruttore custom parametrizzato
    public Animal(string n, Family AnimalFamily, int LegsNumber)
    {
      Name = n;
      this.AnimalFamily = AnimalFamily;     // uso di "this" per disambiguare il nome
      this.LegsNumber = LegsNumber;
    }
  }

  // esempio di tipo enumerato
  public enum Family
  {
    Mammals,
    Birds,
    Fishes
  }
}
