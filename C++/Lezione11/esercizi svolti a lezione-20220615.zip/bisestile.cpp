//Autore: Valentino Armando
// bisestile
// programma che calcola se un anno � bisestile  o no
// un anno � bisestile se � divisibile per 400
// oppure se � divisibile per 4 e non � divisibile per 100
// fare controllo input e funzione bisestile

#include <iostream>
#include "myinput.h"
using namespace std;

bool bisestile(int anno){
	bool bis=false;
	if(anno%400==0){
		bis=true;
	}
	if(anno%4==0 && anno%100!=0){
		bis=true;
	}
	return bis;
}

int main(){
	double n;
	bool bis;
	n=myinput(n);
	cout << "hai inserito "<<n<<endl;
	bis=bisestile(n);
	if(bis==true){
		cout << "anno bisestile!!"<<endl;
	}else{
		cout << "anno NON bisestile!!"<<endl;
	}
	return 0;
}

