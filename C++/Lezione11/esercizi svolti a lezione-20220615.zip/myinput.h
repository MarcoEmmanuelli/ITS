#include <iostream>
#include "controllonumerico.h"
using namespace std;
double myinput(double n){
	do{
		cout << "Inserisci un numero: "<<endl;
		cin>>n;
	}while(controllonumerico()==false);
	return n;
}


