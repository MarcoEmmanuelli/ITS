//Autore: Valentino Armando
// programma con una funzione che prende in input 3 numeri e si calcola il doppio di ogni numero
// tramite la funzione

#include <iostream>
using namespace std;

void inputnumeri(double &n1, double &n2, double &n3){
	cout <<" inserisci numero 1:"<<endl;
	cin >>n1;
	cout <<" inserisci numero 2:"<<endl;
	cin >>n2;
	cout <<" inserisci numero 3:"<<endl;
	cin >>n3;
}

void raddoppia(double &m1, double &m2, double &m3){
	m1=m1*2; // m1*=2;
	m2=m2*2;
	m3=m3*2;
}

void stampa(double a1, double a2, double a3, bool tipo, double r){
	if(tipo==true){
		cout <<a1<<" ; "<<a2<<" ; "<<a3<<endl;
	}
	if(tipo==false{
		cout <<r<<endl;
	}
}

double divisione(double n1, double n2){
	double r;
	r= n1/n2;
	return r;	
}

bool divisione2(double n1, double n2, double &r){
//	double r;
	bool err=false;
	if(n2!=0){
		r= n1/n2;
		err=true;
	}
	return err;	
}

int main(){
	double num1,num2,num3;
	double risultato;
	inputnumeri(num1,num2,num3); 	
//	cout <<num1<<" ; "<<num2<<" ; "<<num3<<endl;
	raddoppia(num1,num2,num3);
//	cout <<num1<<" ; "<<num2<<" ; "<<num3<<endl;
	stampa(num1,num2,num3,true,risultato);
//	risultato=divisione(num1,num2);
	bool err=divisione2(num1,num2,risultato);
	if(err==true)	
		stampa(num1,num2,num3,false,risultato);
	else
		cout << "divisione non si pu� fare!!";
			
	return 0;
}

