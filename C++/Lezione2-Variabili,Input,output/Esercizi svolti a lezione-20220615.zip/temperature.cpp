// calcolo media temperature 
#include <iostream>
using namespace std;
int main(){
	float temperatura, media;
	media=0;
	cout <<"inserisci la prima temperatura:";
	cin >> temperatura;
	media=media+temperatura;
	cout <<"inserisci seconda temperatura:";
	cin >> temperatura;
	media=media+temperatura;
	cout <<"inserisci terza temperatura:";
	cin >> temperatura;
	media=media+temperatura;
	cout <<"inserisci quarta temperatura:";
	cin >> temperatura;
	media=media+temperatura;
	media=media/4;
	cout << " la temperatura media e\':345"<<media;
	fflush(stdin);
	getchar();

}
