/*
come scrivere istruzioni su pi� righe
*/
#include <iostream>
using namespace std;
int main(){

	cout << "prima riga";

	cout << "seconda riga"<<endl;
	cout << "nuova riga molto lunga"
			" LA RIGA CONTINUA ANCORA SU VIDEO"
			"\nin questo viene stampato su una riga nuova"
			<< endl;
	cout <<"\n";
	getchar();
}
