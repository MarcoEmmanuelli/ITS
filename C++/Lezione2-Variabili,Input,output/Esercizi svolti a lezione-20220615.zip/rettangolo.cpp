//calcolo area rettangolo
#include <iostream>
using namespace std;
int main(){
	int latoA;
	int latoB;
	int area;
	cout <<"inserisci il valore del lato A"<<endl;
	cin>> latoA;
	latoB=20;
	cout << "latoB = "<<latoB;
	area=latoA*latoB;
	cout <<"\n------------------------------------------------";
	cout << "\n|Programma che calcola l'area di un rettangolo|";
	cout << "\n| valore del primo lato   = "<< latoA<<"------|";
	cout << "\n| valore del secondo lato = "<<latoB <<"------|";
	cout << "\n| caloclo dell'area       = "<<area<<"--------|";
	cout << "\n|----------------------------------------------";
	cout <<endl;
	fflush(stdin);
	getchar();
}
