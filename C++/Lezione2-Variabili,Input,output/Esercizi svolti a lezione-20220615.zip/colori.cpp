// cambiare colore allo schermo
#include <iostream>
#include <cstdlib>

using namespace std;
int main(){
	system("TITLE COLORI");
	system("CLS");
	system("COLOR 5c");
	cout <<" 0-nero			8-grigio\n";
	cout <<" 1-Blu scuro	9-blu\n";
	cout <<" 2-Verde		A-Verde limone\n";
	cout <<" 3-Verdeacqua	B-Azzurro\n";
	cout <<" 4-Bordeaux		C-Rosso\n";
	cout <<" 5-Viola		D-Fucsia\n";
	cout <<" 6-Verde oliva	E-Giallo\n";
	cout <<" 7-Grigio chiaroF-Bianco\n";
	cout <<endl;
	
}

