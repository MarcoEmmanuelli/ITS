//Autore: Valentino Armando
#include <iostream>
using namespace std;
int main(){
	int n;
	bool r=false;
	do{
		cout << "Inserisci un numero intero: (0-per terminare)"<<endl;
		cin>>n;
		cout << "fail()= "<<cin.fail()<<endl;
		if(n==1000){
			r=true;
		}
		
	}while(r==false);

	return 0;
}

