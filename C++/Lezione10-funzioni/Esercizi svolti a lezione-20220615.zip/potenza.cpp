//Autore: Valentino Armando
#include <iostream>
using namespace std;
int potenza(int m, int n){
	int p=1;
	for( int i=1;i<=n;i++){
		p=m*p;
	}
	return p;
}

int main(){
	int a,b;
	cout << "inserisci numero b:"<<endl;
	cin >>b;
	cout << "inserisci numero a:"<<endl;
	cin >>a;
	cout << "potenza di b^a = "<<potenza(b,a)<<endl;
	return 0;
}

