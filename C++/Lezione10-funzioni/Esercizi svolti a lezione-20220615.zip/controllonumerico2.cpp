//Autore: Valentino Armando
#include <iostream>
#include "controllonumerico.h"

int main(){
	int n;
	do{
		cout << "Inserisci un numero intero: "<<endl;
		cin>>n;
	}while(controllonumerico()==false);
	cout << "hai inserito il numero "<<n<<endl;
	return 0;
}

