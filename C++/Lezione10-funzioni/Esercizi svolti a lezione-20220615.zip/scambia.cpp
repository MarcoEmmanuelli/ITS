//Autore: Valentino Armando
#include <iostream>
using namespace std;
void scambia1( int m, int n){
	int temp;
	temp=m;
	m=n;
	n=temp;
	cout << "M = "<<m<<" n = "<<n<<endl;
}

void scambia2(int &m, int &n){
	int temp;
	temp=m;
	m=n;
	n=temp;
	cout << "M = "<<m<<" n = "<<n<<endl;
}
int main(){

	int b,a;
	cout << "inserisci un numero:"<<endl;
	cin >>a;
	cout << "inserisci un numero:"<<endl;
	cin >>b;
	scambia1(a,b);
	cout << "valore a= "<<a<<" b= "<<b<<endl;
	
	scambia2(a,b);
	cout << "valore a= "<<a<<" b= "<<b<<endl;
	
	system("pause");
	return 0;
}

