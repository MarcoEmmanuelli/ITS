//Autore: Valentino Armando
#include <iostream>
using namespace std;
int main(){
	char c;
	do{
		cout << "inserisci la lettera f o F:";
		cin >>c;
		if((c!='f') && (c!='F')){
			cout << "inserimento errato!!"<<endl;
			cin.clear();
			cin.ignore(1000,'\n');
		}
	}while((c!='f') && (c!='F'));
	return 0;
}

