//Autore: Valentino Armando
#include <iostream>
using namespace std;
int main(){
	int n;
	bool r;;
	do{
		r=true;
		cout << "Inserisci un numero intero: (0-per terminare)"<<endl;
		cin>>n;
		cout << "fail()= "<<cin.fail()<<endl;
		if(cin.fail()){	//input errato
			cout << "errore!! inserimento errato!!"<<endl;
			cin.clear();
			cin.ignore(1000,'\n');
			r=false;
		}else{		// caso di input parzialmente
			cin.ignore(1000,'\n');
			if(cin.gcount()>1){
				cout << "errore!! inserimento errato!!"<<endl;
				r=false;
			}
			
		}
		
	}while(r==false);
	cout << "hai inserito il numero"<<n<<endl;
	return 0;
}

