//Autore: Valentino Armando
#include <iostream>
using namespace std;
int main(){

	int i=0;
	for(int k=0;k<=255;k++){
		i++;
		printf(" %d \t%c  \n",k,k);
		if(i>=25){
			system("pause");
			i=0;
		}
	}
	return 0;
}

