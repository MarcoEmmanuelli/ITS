//Autore: Valentino Armando
// stampare la frase buongiorno a tutti 10 volte
#include <iostream>
using namespace std;
int main(){

 	int conta=0;
 	do{
// 		conta=conta+1;
 		conta++;
 		cout << "  "<<conta<<" buongiorno a tutti!"<<endl;
	 }while(conta<10);
 
 	int n=1;
 	
 	while(n<=10){
		cout << "salve a tutti!"<<endl; 		
//		n=n+1;
		n++;
	}
	int i;
//	i+=2;
//	i=i+1;
//	i++;
	for(int i=1;i<=10;i++){
		cout << i<<" - buonasera a tutti !"<<endl;
	}
	cout <<i<<endl;
	return 0;
}

