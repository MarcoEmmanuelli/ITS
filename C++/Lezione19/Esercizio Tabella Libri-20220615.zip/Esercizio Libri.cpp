#include <iostream>
//#include "controlloinput.h"
using namespace std;
#define MAX 100
struct tipolibro{
	string titolo, autore, editore;
	int numpagine;
	double prezzo;	
};

int leggidimensione(int max){
	cout << "Quanti libri vuoi inserire? (massimo "<<max<<" )"<<endl;
	cin >> max;
	return max;
}

tipolibro InserisciDatiLibro(){
	tipolibro libro;
	fflush(stdin);
	cout <<"Inserire il titolo: "<<endl;
	getline(cin,libro.titolo);
	cout <<"Inserire l'autore: "<<endl;
	getline(cin,libro.autore);
	cout <<"Inserire editore: "<<endl;
	getline(cin,libro.editore);
	cout <<"Inserire Numero di pagine: "<<endl;
	cin >> libro.numpagine;
	cout <<"Inserire Prezzo: "<<endl;
	cin >> libro.prezzo;
	return libro;
}
void InserisciLibroinTabella(tipolibro libri[], int dim){
	for (int i=0; i<dim;i++){
		cout <<" inserisci il libro n. "<<i+1<<endl;
		libri[i]=InserisciDatiLibro();
	}
}

void StampaTabellaLibri(tipolibro libri[], int dim){
	cout<<"Titolo"<<"\t"<<"Autore"<<"\t"<<"Editore"<<"\t"<<"N. Pagine"<<"\t"<<"Prezzo"<<endl;
	for (int i=0; i<dim;i++){
		cout << libri[i].titolo<<"\t"<<libri[i].autore<<"\t"<<libri[i].editore<<"\t"
			<<libri[i].numpagine<<"\t"<<libri[i].prezzo<<endl;
	}
}

void scambia(tipolibro &a, tipolibro &b){
	tipolibro c;
	c=a;
	a=b;
	b=c;
}

void OrdinaperEditore(tipolibro libri[], int dim){
	for (int i=0; i<dim-1;i++) {
		for(int j=i+1; j<dim; j++){
			if (libri[i].editore > libri[j].editore) {
				scambia(libri[i], libri[j] );
			}
		}
	}
}

 
int main() {
	tipolibro libri[MAX]; 	// tabella di libri
	int n;
	cout << "************* Programma che crea una tabella di libri *******"<<endl;
	// chiede quanti libri inserire
	n=leggidimensione(MAX);
	// inserisci dati di un libro
//	tipolibro L = InserisciDatiLibro();
	// inserisci libro nella tabella
	InserisciLibroinTabella(libri, n);
	// stampa della tabella libri
	cout << "********** STAMPA TABELLA LIBRI *************"<<endl;
	StampaTabellaLibri(libri , n);
	// ordina tabella libri per editore
	cout << "********** STAMPA TABELLA LIBRI ORDINATA PER EDITORE*************"<<endl;
	OrdinaperEditore(libri,n);
	StampaTabellaLibri(libri , n);

	
		
}
