/*
programma che prende N numeri in input e termina su richiesta dell'utente
*/
#include <cstdlib>
#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
	char s;
	int somma;
	int n;
	int conta;
	do
	{
		conta=conta+1;
		cout << "\nInserire un numero: ";
		cin >> n;
		somma = somma + n;
		cout << "Continuare?" << endl << "[s / n]" << endl;
		s = getch();
		cout << endl;
		system("CLS");
	}while(s == 's' || s='S');
	cout << "\n\t\tsomma di tutti i numeri inseriti: " << somma;
	cout <<" numero di input:"<<conta<<endl;
}
