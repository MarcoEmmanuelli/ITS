//Scrivere un programma che prende N numeri in input e termina su richiesta dell'utente
#include <iostream>
#include <cstdlib>
using namespace std;
int main(){
	system("COLOR 02");
	int n,somma=0,i=0;
	bool seTermina=true;
	do{
		cout << "Inserire un numero (inserire '0' per terminare): ";
		cin >> n;
		if(n!=0){
			somma=somma+n;
			i++;
		}else{
			seTermina=false;
		}
		system("CLS");
	}while(seTermina);
	cout << "La somma vale: " << somma << endl;
	cout << "Sono stati sommati " << i << " numeri";
	fflush(stdin);
	getchar();
	return 0;
}
