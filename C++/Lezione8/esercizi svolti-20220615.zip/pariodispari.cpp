//Autore: Valentino Armando
// dati n numeri in input calcolare quanti numeri sono pari 
// e quanti numeri sono dispari;
#include <iostream>
using namespace std;
int main(){
	//1 chiedere all'utente quanti numeri vole inserire
	//2 prendere l'input 
	//3 chiedere all'utente di inserire un numero
	//4 prendere un numero in input
	//5 verificare se � pari o dispari
	//6 contare i numeri pari e i numeri dispari
	//7 ripetere di nuovo ->prendere un numero in input dal punto 4
	return 0;
}

