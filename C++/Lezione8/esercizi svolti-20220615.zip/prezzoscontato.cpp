//Autore: Valentino Armando
/*
inserire pi� prezzi dalla tastiera per acquisti che l'utente fa in un negozio.
 applicare uno sconto del 15 % se il totale degli acquisti � superiore a 125
 e il 25% se il totale � superiore a 300. 
 Stampare il totale scontato, lo sconto totale e in numero prodotti acquistati
*/
#include <iostream>
using namespace std;
int main(){
	double prezzo;
	double totale=0;
	int termina;
	int numeroprodotti=0;
	double  totalescontato,sconto;
	do{
	//1. prendere prezzo in input
		double prezzo;
		cout << "inserisci un prezzo:"<<endl;
		cin >> prezzo;
	//2. sommare il prezzo al precedente 
		totale=totale+prezzo;
	//3. chiedere all'utente se vuole terminare l'input
		cout << "vuoi terminare? (0-termina 1-continua)"<<endl;
		cin >> termina;
	//4. ripetere dal punto 1 fino a quando l'utente vuole terminare
		numeroprodotti=numeroprodotti+1;
	}while(termina!=0);
	//5. se la somma > 125 applica sconto del 15%
	if(totale>125 && totale<=300){
		sconto=totale*15/100;
		totalescontato=totale-sconto;
	}else{
	}
	//6. se la somma >300 applica sconto del 25%
	if(totale>300){
		sconto=totale*25/100;
		totalescontato=totale-sconto;
	}
	//7. stampa totale scontato, sconto totale e numero di prodotti
	cout << " totale scontato: "<<totalescontato <<endl;
	cout << "scoto totale: "<<sconto<<endl;
	cout << "numero di prodotti acquistati: "<<numeroprodotti;
	return 0;
}

