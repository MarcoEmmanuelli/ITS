//Autore: Valentino Armando
// Calcola e stampa la somma dei numeri interi da 0 fino a un 
// numero letto in input 
#include <iostream>
using namespace std;
int main(){
	int n;
	int somma=0;
	int conta=0;
	// leggere un numero in input
	cout << "inserisci il numero massimo numero di cui vuoi fare le somme:"<<endl;
	cin >> n;
	// sommare tutti i numeri a partire da 0 fino al numero letto in input
/*	for(int i =0; i<=n;i++){
		somma=somma+i;
	}
*/
	while(conta<=n){
		somma=somma+conta;
		conta=conta+1;
	}
	// stampa della somma calcolata
	cout <<" la somma dei numeri vale: "<<somma<<endl;
	return 0;
}

