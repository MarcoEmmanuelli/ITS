// aplicazione con uso dei puntatori per creare una tabella di film;
#include <iostream>
using namespace std;
struct tipofilm{
	string titolo;
	int durata; 
	int anno;
};

tipofilm Inserisci_film(tipofilm *f ){
	
	cout <<"inserisci il titolo del film:"<<endl;
	getline(cin, f->titolo);
	cout << "inserisci la durata: "<<endl;
	cin>> f->durata;
	cout << "inserisci l'anno: "<<endl;
	cin>> f->anno;

	return *f;
}

void printfilm(tipofilm *f ){
	cout <<"Titolo Film: "<<f->titolo<<endl;
	cout <<" Durata: "<<f->durata<<endl;
	cout<<" Anno: "<<f->anno<<endl;
//	cout<< (*f).anno<<endl;
}


int main(){
	tipofilm f1;
	// inserimento dati film;
	f1=Inserisci_film(&f1);
	//stampa dati della tabella film
	printfilm(&f1);
	
}
