#include <iostream>

using namespace std;
int main(){
	int a=10;
	int b;
	int *pi;
	pi = &a;
	b=*pi; // prende il contenuto della variabile a cui punta, cio� il conteunto di a
	*pi=500;
	cout <<"\t pi = "<<pi<<endl;
	cout <<"\t &a = "<< &a<<endl;
	cout << "\t &pi ="<<&pi<<endl;
	cout <<"b = "<<b<<endl;
	
	cout << "sizeof(pc) ="<<sizeof(pi)<<endl;
	cout << " a= "<<a<<endl;
}
