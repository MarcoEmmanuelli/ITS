// scambia il valore di due variabili
#include <iostream>
using namespace std;
int main(){
	int n1,n2;
	cout << "inserisci il primo numero"<<endl;
	cin >> n1;
	cout << "inserisci il secondo numero"<<endl;
	cin >> n2;
	cout << " i valori che hai inserito n1 e n2 sono i seguenti:" << n1 << " "<< n2<<endl;
	system("pause");
	
	int n3;
	n3 = n1;
	n1 = n2;  // operazione distruttiva del valore contenuto in n1
	n2 = n3;
	cout << " i nuovi valori scambiati di n1 e n2 sono i seguenti: "<< n1 <<" "<<n2<<endl;
	system("pause");
	return 0;
}
