// programma che inserisce un numero da tastiera e lo visualizza al video
#include <iostream>
using namespace std;
int main(){
	cout << "inserisci un numero da tastiera: ";
	int n;
	cin >> n;
	cout << "il numero che hai inserito e:" <<n <<endl;
}
