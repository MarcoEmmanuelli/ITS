#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int const n = 5;
// riempie la matrice con numeri da 1 a 10
void riempiMatrice(int mat[][n], int col, int rig){
	for (int i=0; i <rig; i++ ){
		for (int j=0; j<col; j++){
			mat[i][j]=rand() % 10 +1;
		}
	}
}

void stampaMatrice(int mat[][n], int col, int rig){
  for (int i=0; i <rig; i++ ){
		for (int j=0; j<col; j++){
			cout << mat[i][j] <<"\t";
		}
		cout << endl;
  }	
}

void Prodotto(int matA[][n], int matB[][n], int matC[][n], int n){
  for (int i=0; i <n; i++ ){
		for (int j=0; j<n; j++){
     	 matC[i][j]= matA[i][j]*matB[i][j];
    }
  }
}
void Somma(int matA[][n], int matB[][n], int matD[][n], int n){
  for (int i=0; i <n; i++ ){
		for (int j=0; j<n; j++){
     	 matD[i][j]= matA[i][j]+matB[i][j];
    }
  }
}

int main(){
  int matA[n][n];
  int matB[n][n];
  int matC[n][n];
  int matD[n][n];
    srand(time(NULL));
  cout << "riempi la prima matrice" << endl; 
  riempiMatrice(matA,n,n);
  cout << "stampa matrice A" << endl; 
    stampaMatrice(matA,n,n);
  cout << "riempi la seconda matrice" << endl; 
  riempiMatrice(matB,n,n);
  cout << "stampa matrice B" << endl; 
    stampaMatrice(matB,n,n);
  cout << "calcolo prodotto delle matrici " << endl; 
  Prodotto(matA, matB, matC, n);
	cout << "\nStampa matrice prodotto" << endl; 
  stampaMatrice(matC,n,n);
  cout << "calcolo somma delle matrici " << endl; 
  Somma(matA, matB, matD, n);
	cout << "\nStampa matrice somma" << endl; 
  stampaMatrice(matD,n,n);

} 
