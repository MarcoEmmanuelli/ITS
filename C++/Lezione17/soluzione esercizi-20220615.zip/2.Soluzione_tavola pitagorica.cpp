

#include <iostream>
#define DIMX 10
#define DIMY 10
using namespace std;

void calcolaMat(double mat[][DIMY], int dimX, int dimY){
  int x, y;
  for (y = 0; y < dimY; y++)        // riempi la matrice per righe 
    for (x = 0; x < dimX; x++) 
      mat[x][y]=(x+1)*(y+1);
}
void stampaMat(double mat[][DIMY], int dimX, int dimY){
  int x, y;
  for (y = 0; y < dimY; y++){  
    printf("\n\n");
    for (x = 0; x < dimX; x++) {
	   cout << "\t"<<mat[x][y];
    }
  }
}
int  main(){
  double mioMat[DIMX][DIMY];       
  calcolaMat(mioMat, DIMX, DIMY);
  stampaMat(mioMat, DIMX, DIMY);
  cout << "\n\n";
  system("pause");
}



 



   















