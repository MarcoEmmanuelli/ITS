#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;
#define maxcol 8
#define maxriga 40

void stampaMediaStudente(int stud, int conta, double media){
	cout << "studente "<<stud<< " esami superati: "<<conta<<" media degli esami: "<<media<<endl;
}

void calcolaMediaEsami(int mat[][maxcol], int riga, int col){
	int i,j,conta;	double somma;
	for(int i=0; i<riga; i++){
		conta=0; somma=0;
		for (int j=0; j<col; j++){
			if(mat[i][j] > 0) {
				conta=conta+1;
				somma=somma+mat[i][j];
			}
		}
		if(somma>0){
			stampaMediaStudente(i+1,conta, somma/conta);
		}	
	}
}

void caricamatrice(int mat[][maxcol], int riga,int col){
	srand(time(NULL)); 
	for(int i = 0; i < riga; i++){
		// studente i
		for (int j=0; j<col; j++){
			mat[i][j] = ((rand() % 10) + 0); 
		}
	}
}



int main(){
	int riga=32;
	int col=5;
	int mat[maxriga][maxcol];
	caricamatrice(mat, riga, col);
	calcolaMediaEsami(mat, riga, col);

	system("pause");
}

