#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;
#define DIM 50

int carica(int vet[], int max){
	for(int i = 0; i < max; i++){
		vet[i] = ((rand() % 81) + 20); 
	}
}
void stampa(int vet[],int max){
	int x=1;
	for(int i = 0; i < max; i++){
		printf(" %d \t", vet[i]); 
		if(x==20){
			printf("\n");
			x=1;
		}
	}
	printf("\n");
}

int calcolaMinimo(int vet[], int max){
	int min=vet[0];
	for(int i = 0; i < max; i++){
		if(vet[i] <min){
			min = vet[i]; 
		}
	}
	return min;
}
int calcolaMassimo(int vet[], int max){
	int mas=vet[0];
	for(int i = 0; i < max; i++){
		if(vet[i] >mas){
			mas = vet[i]; 
		}
	}
	return mas;
}

double calcolaMedia(int vet[], int max){
	double somma=0;
	for(int i = 0; i < max; i++){
			somma = somma+vet[i]; 

	}
	return somma/max;
}
void stampa(int min,int max, double media){
	cout << "Il valore minimo: "<<min<<endl;
	cout << "Il valore massimo: "<<max<<endl;
	cout << "Il valore medio: "<<media<<endl;
}
void copyArray(int source[], int dest[], int dim) {
	for (int i = 0; i < dim; i++) {
		dest[i] = source[i];
	}
}

void copiaInversoArray(int source[], int dest[], int dim) {
	for (int i = 0; i < dim; i++) {
		dest[dim-1-i] = source[i];
	}
}

int main(){
	srand(time(NULL));
	int vet[DIM];
	int copia[DIM], copia2[DIM];
	int min,max;
	double media;
	cout <<"caricamento array con numeri da 20 a 100\n";
	carica(vet,DIM);
	min=calcolaMinimo(vet,DIM);
	max=calcolaMassimo(vet,DIM);
	media=calcolaMedia(vet,DIM);
	cout <<"\nstampa array di numeri casuali\n";	
	stampa(vet,DIM);
	stampa(min,max,media);
	cout <<	"\nCopia Array random in array vuoto\n" ;	
	copyArray(vet,copia,DIM);
	cout <<"\nstampa copia array di numeri casuali\n" ;	
	stampa(copia,DIM);
	cout <<"\nCopia Array random in modo inverso in array vuoto\n" ;	
	copiaInversoArray(vet,copia2,DIM);	
	cout <<	"\nstampa copia inversa array di numeri casuali\n";	
	stampa(copia2,DIM);
	system("pause");
}
