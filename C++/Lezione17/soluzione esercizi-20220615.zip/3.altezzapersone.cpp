/*Scrivi un programma che usa le funzioni per caricare in memoria una matrice A (10 x 10) 
i numeri interi indicanti l�altezza di persone scelti con una funzione random.
Ogni elemento della matrice rappresenta l�altezza di una persona.
Caricare la matrice di numeri random e stampare la matrice mediante funzioni
*/
//Autore: Valentino Armando
#include <iostream>
#include <cstdlib>
#include <ctime>

#define DIM 10
using namespace std;
void carica_matrice(int M[][DIM], int max){
	for(int i=0; i<max; i++){
		for( int j=0; j<max;j++){
			M[i][j]=rand()%(121)+50;  // altezze da 50 cm a 170 cm
			// a= (rand()% (massimo - minimo+1)+minimo);
		}
	}
}

void stampa_matrice(int M[][DIM], int max){
	for(int i=0; i<max; i++){
		for( int j=0; j<max;j++){
			cout << "\t"<<M[i][j];
			// a= (rand()% (massimo - minimo+1)+minimo);
		}
		cout <<endl;
	}
}

int calcolaAlto(int M[][DIM], int max, int &r, int &c){
	int v=M[0][0] ;
	for(int i=0; i<max; i++){
		for( int j=0; j<max;j++){
				if(M[i][j] >v){
					v=M[i][j];
					r=i;
					c=j;
				}
		}
	}
	return v;
}

int piuBasso_Alti(int M[][DIM], int max, int &p){
	int AltiPerRiga[max];
	int v;
	for(int i=0; i<max; i++){
		v=0;
		for( int j=0; j<max;j++){
				if(M[i][j] >v){
					v=M[i][j];
				}
		}
		AltiPerRiga[i]=v;
	}	
	v=AltiPerRiga[0];
	for(int k=0;k<max;k++){
		if(AltiPerRiga[k]<v){
			v=AltiPerRiga[k];
			p=k;
		}
//		cout <<"\t "<<AltiPerRiga[k]<<endl;
	}
	return v;
}

int piuAlto_Bassi(int M[][DIM], int max, int &p){
	int BassiPerColonna[max];
	int v;
	for(int j=0; j<max; j++){
		v=M[j][0];
		for( int i=0; i<max;i++){
				if(M[i][j]<v){
					v=M[i][j];
				}
		}
		BassiPerColonna[j]=v;
	}	
	v=BassiPerColonna[0];
	for(int k=0;k<max;k++){
		if(BassiPerColonna[k]>v){
			v=BassiPerColonna[k];
			p=k;
		}
//		cout <<"\t "<<BassiPerColonna[k]<<endl;
	}
	return v;
}


int main(){
	int altezza[DIM][DIM];
	int piualto;
	int riga,col;
	int b,p;
	srand(time(NULL));
	carica_matrice(altezza, DIM);
	stampa_matrice(altezza, DIM);
	// persona pi� alta
	piualto=calcolaAlto(altezza,DIM,riga,col);
	cout<< "la persona pi� alta �: "<<piualto<<" nella posizione riga= "<<riga+1<<" e colonna= "<<col+1<<endl;
	b=piuBasso_Alti(altezza,DIM,p);
	cout << "il piu basso degli alti �: "<<b<<" alla riga: "<<p<<endl;

	b=piuAlto_Bassi(altezza,DIM,p);
	cout << "il piu Alto dei bassi �: "<<b<<" alla colonna: "<<p<<endl;
	
	return 0;
}

