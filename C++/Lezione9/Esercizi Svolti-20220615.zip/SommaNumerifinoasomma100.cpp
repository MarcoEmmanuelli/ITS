//Scrivere un programma che legga una sequenza di valori numerici fino a che 
// la loro somma � minore di 100
//Stampare la somma ottenuta e quanti sono i numeri letti
#include <iostream>
using namespace std;
int main()
{
	setlocale(LC_ALL, "Italian");
	int x = 0, y = 0, c = 0;
	while(true)
	{
		cout <<"Inserisci numero: "<<endl;
		cin >>x;	
		y = y + x;	
		c = c + 1;		
		if (y>100)
		{
			y = y - x;
			break;
		}	
	}
	c = c -1;
	cout <<"La somma �: " <<y <<endl <<"Hai sommato " <<c <<" numeri."<<endl;
	system("pause");
	return 0;
}
