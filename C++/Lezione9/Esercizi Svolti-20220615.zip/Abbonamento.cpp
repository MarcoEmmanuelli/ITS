#include <iostream>
#define T1S 10
#define T2S 5
#define T3S 15
#define T1M 30
#define T2M 20
#define T3M 40
#define T1A 250
#define T2A 150
#define T3A 300
#define SCONTO 20/100

// 1. inserire  Tipo abbonamento (1,2 o 3)
// 2. inserire periodo (S, M, A)
// 3. inserire priorit� (B, N)
// 4. se tipo 1 allora 
// 5.			--verificare periodo e calcolare abbonamento
// 6.  altrimenti se tipo2
// 7.			--verificare periodo e calcolare abbonamento
// 8.  altrimenti se tipo3
// 9.			--verificare periodo e calcolare abbonamento
// 10. se priorit� bassa
// 11.		applicare sconto e calcolare abbonamento
// 12. altrimenti 
// 13.     calcolare abbonamento senza sconto
// 14. chiedere se si vuole terminare o fare altro calcolo
// 15. ripetere dal punto1 o termina.

		

using namespace std;
int main() {
	setlocale(LC_ALL, "Italian");	
  int tipo;
  int valore;
  int abbonamento;
  char periodo;
  char priorita;
	int termina;
  cout << "----- Calcolo del costo di un abbonamento -----"<<endl;

  do {
	  	cout << "inserisci il tipo di abbonamento: \n"
		  		" 1=zona centrale\n 2=zona periferica\n 3=entrambe"<<endl;
	  	cin >> tipo;  	
	    cout << "Inserisci periodo dell'abbonamento\n"
				" S=settimanale\n M=mensile\n A=annuale"<<endl;
	    cin >> periodo;
	    cout << "inserisci priorita' B=bassa, N=normale "
				"(se viaggi nelle ore di punta scegli N)"<<endl;
	    cin >> priorita;
	    if (tipo == 1) {
			switch (periodo) {
				case 'S': case 's':
					abbonamento = T1S;
					break;
				case 'M': case 'm':
					abbonamento = T1M;
					break;
				case 'A': case 'a':
					abbonamento = T1A;
					break;
			}
	    } else if (tipo == 2) {
	    	switch (periodo) {
	    		case 'S': case 's':
	    			abbonamento = T2S;
	    			break;
	    		case 'M': case 'm':
	    			abbonamento = T2M;
	    			break;
	    		case 'A': case 'a':
	    			abbonamento = T2A;
	    			break;
			}
		} else if (tipo == 3) {
			switch (periodo) {
				case 'S': case 's':
					abbonamento = T3S;
					break;
				case 'M': case 'm':
					abbonamento = T3M;
					break;
				case 'A': case 'a':
					abbonamento = T3A;
					break;
			}
		}
	    if (priorita=='B' || priorita=='b' ) {
			valore = abbonamento-(abbonamento*SCONTO);
	    } else{
	    	valore =abbonamento;
		}
	    
		cout << "il costo dell'abbonamento � " << valore<<endl;
		system("pause");
		cout <<"vuoi terminare o fare un altro calcolo? (1-terminare 0- altro calcolo)\n";
		cin >>termina;
  }while (termina==0);
  cout << "fine calcolo abbonamento"<<endl;
}

