//Progettare un algoritmo che, dati due valori numerici h e k, legga n valori 
//e conti quanti di essi sono compresi tra h e k scrivendo il risultato
#include <iostream>
using namespace std;
int main() {
	setlocale(LC_ALL, "Italian");
	int max;
	cout<<"inserisci numero di inizio range"<<endl;
	cin>>max;
	int min;
	cout<<"inserisci numero di fine range"<<endl;
	cin>>min;
	int counter = 0;
	int n_in_range = 0;
	int q;
	cout<<"quanti numeri vuoi inserire?"<<endl;
	cin>>q;
	int n;
	while (counter<q) {
		cout<<"Inserisci prossimo numero"<<endl;
		cin>>n;
		counter++;
		if (n >= min && n <= max || n <= min && n >= max) {
			n_in_range++;
		}
	}
	cout<<"Hai inserito "<<n_in_range<<" numeri compresi tra "<<min<<" e "<<max<<endl;
}
