//Autore: Valentino Armando
#include <iostream>
using namespace std;
int main(){
	int scelta;
	string opzione1="1. opzione1";
	string opzione2="2. opzione2";
	string opzione3="3. opzione3";
	string opzione4="4. opzione4";
	string opzione5="5. opzione5";
	string opzione6="6. FINE";
	do{
		cout <<"********* menu di scelta ********"<<endl;
		cout <<opzione1<<endl;
		cout <<opzione2<<endl;
		cout <<opzione3<<endl;
		cout <<opzione4<<endl;
		cout <<opzione5<<endl;
		cout <<opzione6<<endl;
		cout << " scegli una opzione:"<<endl;
		cin >>scelta;
		switch(scelta){
			case 1:
				cout << "hai scelto opzione 1"<<endl;
				break;
			case 2:
				cout << "hai scelto opzione 2"<<endl;
				break;
			case 3:
				cout << "hai scelto opzione 3"<<endl;
				break;
			case 4:
				cout << "hai scelto opzione 4"<<endl;
				break;
			case 5:
				cout << "hai scelto opzione 5"<<endl;
				break;
			case 6:
				cout << "hai scelto Fine"<<endl;
				break;
		}
		system("pause");
		system("CLS");
	}while(scelta!=6);
	return 0;
}

