/* scrivere un programma che risolve una equazione di 2 grado.
ax2+bx+c=0; 	Es;10x2+4x+5=0
delta=(b*b)-(4*a*c)
delta=0 due soluzioni ugali
		x1 = x2 = -b/2a
delta < 0 
		non ci sono soluzioni reali
delta >0
	x1= -b + radicequadrata(delta)/2a
	x1= -b - radicequadrata(delta)/2a
*/
#include <iostream>
using namespace std;
#include <cmath>
int main(){
  	float a,b,c,delta,x1,x2;
  	cout << "\nInserisci i coefficienti di una equazione di secondo grado";
  	cout << "\n inserisci il valore di a ";
  	cin  >> a;
  	cout << "\n inserisci il valore di b ";
  	cin  >> b;
  	cout << "\n inserisci il valore di c ";
  	cin  >> c;
   	delta = b*b-(4*a*c);
   	cout <<"delta = "<<delta<<endl;
   	if (delta<0){
	    cout << "il discriminante e'negativo: soluzioni non reali";
   	}
   	if (delta==0){
    	x1 =-b/(2*a);
     	cout << "\nl'equazione ha due soluzioni coincidenti " << x1;  
	}
  	if (delta>0){
     	x1 =(-b + sqrt(delta))/(2*a);
    	x2 =(-b - sqrt(delta))/(2*a);
	 	cout << "\nl'equazione ha due soluzioni:" <<endl;
		 cout <<"soluzione 1 = "<< x1<<endl;  
		 cout <<"soluzione 2 = "<< x2<<endl;  
	}
     
}
