#include <iostream>
#include <stdio.h>
#include <conio.h>
using namespace std;
int main ()
{
	char operatore, uguale, s;
	float n1, n2, r;
	cout<<"Il programma e' una calcolatrice\n";
	cout<<"Inserisci i dati: Es: '2 * 3 = ' e premi invio"<<endl; 
	cin >>n1>>operatore>>n2>>uguale;
	cout<<endl;
	if( uguale == '='){
			switch(operatore)
			{
				case '+':
					r= n1 + n2;
					cout<<"L'operazione selezionata e' la somma, il risulato dell'operazione e': "<<r<<endl;
				break;
				case '-':
					r = n1 - n2;
					cout<<"L'operazione selezionata e' la sottrazione, il risulato dell'operazione e': "<<r<<endl;
				break;
				case '*':
					r= n1 * n2;
					cout<<"L'operazione selezionata e' la moltiplicazione, il risulato dell'operazione e': "<<r<<endl;
				break;
				
				case '/':
				if( n2 == 0 )
				{
					cout<<"Operazione non valida"<<endl;
				}
				else
				{
					r= n1 / n2;
					cout<<"L'operazione selezionata e' la divisione, il risulato dell'operazione e': "<<r<<endl;
				}
				break;
				default:
					cout<<"OPERATORE NON VALIDO\n";
				break;
			}
		}
		else
		{
			cout<<"Non hai inserito l'uguale = \n";
		}
	return 0;
}
