// PROGRAMMA CHE SIMULA LA CALCOLATRICE
// prendere in input due numeri e una operazione matematica +,-, *, / 
// e dare il risultato dell'oprazione.
// il risultato dell'operazione deve essere dato premendo dalla tastiera '='
// controllare la sequenza che deve essere: 
// primo numero-> operatore matematico -> secondo numero ->'='
