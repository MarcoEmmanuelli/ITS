//leggere un carattere e riconoscere se � una vocale o una consonante
#include <iostream>
using namespace std;

int main(){
	char lettera;
	cout <<" programma che dice se � una vocale o una consonate"<<endl;
	cout<<"inserire una lettera: ";
	cin >> lettera;
	lettera=tolower(lettera);
/*	if(lettera=='a' || lettera=='e' || lettera=='i' || lettera=='o'|| lettera=='u'){
		cout << " hai inserito una vocale"<<endl;
	}else{
		cout << " hai inserito una consonante"<<endl;
	}
*/
	if(lettera=='a'){
		cout << "hai inserito la lettera a"<<endl;
	}else if(lettera=='e'){
		cout << "hai inserito la lettera e"<<endl;
	}else if(lettera=='o'){
		cout << "hai inserito la lettera o"<<endl;
	}else if(lettera=='i'){
		cout << "hai inserito la lettera i"<<endl;
	}else if(lettera=='u'){
		cout << "hai inserito la lettera u"<<endl;
	}else{
		cout << "non hai inserito una vocale"<<endl;
	}
// si possono sostitire con switch()	
	switch(lettera){
		case 'a':
			cout << "hai inserito la lettera a"<<endl;
			break;
		case 'e':
			cout << "hai inserito la lettera e"<<endl;
			break;
		case 'i':
			cout << "hai inserito la lettera i"<<endl;
			break;
		case 'o':
			cout << "hai inserito la lettera o"<<endl;
			break;
		case 'u':
			cout << "hai inserito la lettera u"<<endl;
			break;
		default :
			cout << "non hai scelto una vocale!!"<<endl;
			break;
	}
	int x=10;
	X=X+2;
	X+=2;
	
}
