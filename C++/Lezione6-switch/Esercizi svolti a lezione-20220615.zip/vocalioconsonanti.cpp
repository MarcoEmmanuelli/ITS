//leggere un carattere e riconoscere se � una vocale o una consonante
#include <iostream>
using namespace std;

int main(){
	char lettera;
	cout <<" programma che dice se � una vocale o una consonate"<<endl;
	cout<<"inserire una lettera: ";
	cin >> lettera;
	lettera=tolower(lettera);
	if(lettera=='a' || lettera=='e' || lettera=='i' || lettera=='o'|| lettera=='u'){
		cout << " hai inserito una vocale"<<endl;
	}else{
		cout << " hai inserito una consonante"<<endl;
	}
	
}
