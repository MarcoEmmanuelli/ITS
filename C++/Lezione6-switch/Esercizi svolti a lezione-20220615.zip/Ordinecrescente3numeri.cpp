#include<iostream> 
using namespace std;
int main(){ 
int num1,num2,num3;

cout<<"inserisci il primo numero: ";
cin >>num1;
cout<<"inserisci il secondo numero: ";
cin >>num2;
cout<<"inserisci il terzo numero: ";
cin >>num3;
cout<<"stampa dei nomi in ordine crescente: "<<endl;

if(num1<num2 && num2<num3) {        // 1  2  3                           
  cout<<num1<<endl<<num2<<endl<<num3<<endl;         	 
}
if(num1<num3 && num3<num2) {   // 1  3  2 
	 cout<<num1<<endl<<num3<<endl<<num2<<endl; 
}
if(num2<num1 && num1<num3) {   // 2  1  3
   cout<<num2<<endl<<num1<<endl<<num3<<endl;            
}
if( num2<num3 && num3<num1 ) {  // 2  3  1
   cout<<num2<<endl<<num3<<endl<<num1<<endl;
}
if( num3<num1 && num1<num2) {  //  3  1  2  
	cout<<num3<<endl<<num1<<endl<<num2<<endl;
}
if( num3<num2 && num2<num1) {  // 3  2  1
    cout<<num3<<endl<<num2<<endl<<num1<<endl;
}
fflush(stdin);
getchar();
}
