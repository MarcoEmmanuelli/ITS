//Autore: Valentino Armando
#include <iostream>
#include "controllonumerico.h"

using namespace std;
double c_minimo(double c1, double c2, double c3){
	double min=c1;
	if(c2<min){
		min=c2;
	}
	if(c3<min){
		min=c3;
	}
	return min;
}

double calcola_minimo(double c1, double c2, double c3){
	double min;
	//c1<c2<c3 c1<c3<c2
	if(( c1<=c2 && c2<=c3) || ( c1<=c3 && c3<=c2)){
		min=c1;
	}
	//c2<c1<c3 c2<c3<c1
	if( (c2<=c1 && c1<=c3) || ( c2<=c3 && c3<=c1)){
		min=c2;
	}
	//c3<c2<c1  c3<c1<c2
	if((c3<=c2 && c2<=c1) || (c3<=c1 && c1<=c2)){
		min=c3;
	}
}
double c_massimo(double c1, double c2, double c3){
	double max=c1;
	if(c2>max){
		max=c2;
	}
	if(c3>max){
		max=c3;
	}
	return max;
}

double calcola_massimo(double c1, double c2, double c3){
//	max=0;
	double max;
	//c1<c2<c3 c2<c1<c3
	if(( c1<=c2 && c2<=c3) || (c2<=c1 && c1<=c3)){
		max=c3;
	}
	//c1<c3<c2 c3<c1<c2
	if(( c1<=c3 && c3<=c2) || (c3<=c1 && c1<=c2)){
		max=c2;
	}
	// c2<c3<c1  c3<c2<c1	
	if(( c2<=c3 && c3<=c1) || (c3<=c2 && c2<=c1)){
		max=c1;
	}
	return max;
}

double calcola_media(double c1, double c2, double c3){
	return (c1+c2+c3)/3;
	
}

void input_dati(double &p1, double &p2, double &p3){
	cout <<"Inserisci primo numero: "<<endl;
	cin >>p1;
	cout <<"Inserisci secondo numero: "<<endl;
	cin >>p2;
	cout <<"Inserisci terzo numero: "<<endl;
	cin >>p3;
}


int Menu(){
	int scelta;
	//----
	do{
		system("CLS");
		cout << "\n\n**** Calcolo del massimo, minimo, media di 3 Numeri ****"<<endl;
		cout << "\t\t1. Input numeri"<<endl;
		cout << "\t\t2. Media"<<endl;
		cout << "\t\t3. Minimo"<<endl;
		cout << "\t\t4. Massimo"<<endl;
		cout << "\t\t5. Fine"<<endl;
		cin >> scelta;
		if( controllonumerico()==false || (scelta <1 )|| (scelta >5)){
			cout << "\n\nERRORE!!! Digitare la scelta corretta....\n\n";
			system("PAUSE");
			scelta=0;
		}
		
	}while((scelta <1 )|| (scelta >5));
	//--------
	return scelta;
}

int main(){
	double n1,n2,n3;
	int scelta;
	double media,massimo,minimo;
	bool input =false;
	do{
		system("CLS");
		scelta=Menu();
		switch(scelta){
			case 1:
				input_dati(n1,n2,n3);
				input=true;
//				cout << "scelta 1 --"<<n1<<"; "<<n2<<"; "<<n3<<endl;
				break;
			case 2:
				if(input==true){
					media=calcola_media(n1,n2,n3);
					cout << "\nMedia dei numeri: "<<media<<endl;
				}else{
					cout <<"\nDati non inseriti!! Inserisci prima i dati"<<endl;
				}
		//		cout << "scelta 2"<<endl;
				break;
			case 3:
				if(input==true){
					//minimo=calcola_minimo(n1,n2,n3);
					minimo=c_minimo(n1,n2,n3);
					cout << "\nMinimo dei numeri: "<<minimo<<endl;
				}else{
					cout <<"\nDati non inseriti!! Inserisci prima i dati"<<endl;
				}
				
//				cout << "scelta 3"<<endl;
				break;
			case 4:
				if(input==true){
					//massimo=calcola_massimo(n1,n2,n3);
					massimo=c_massimo(n1,n2,n3);
					cout << "\nMassimo dei numeri: "<<massimo<<endl;
				}else{
					cout <<"\nDati non inseriti!! Inserisci prima i dati"<<endl;
				}
//				cout << "scelta 4"<<endl;
				break;
			case 5:
				cout << "scelta 5"<<endl;
				cout << "Grazie per aver utilizzato il programma..."<<endl<<endl;
				break;
		}
		system("PAUSE");
	}while(scelta!=5);

	return 0;
}

