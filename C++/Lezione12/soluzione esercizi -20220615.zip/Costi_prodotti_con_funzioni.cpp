/*
Scrivere una applicazione che prende  in input 3 prodotti formati dal Nome, prezzo e Quantit� e 
che stampi il prodotto dal costo pi�� alto, quello dal costo pi� basso. 
Il costo del prodotto � dato dal Prezzo x Quantit�.
Utilizzare  funzione per l'input, per il costo pi� alto e per il costo pi� basso.
Scrivere un menu per l'utilizzo dell'applicazione come segue:
*****************************************************
	Calcolo dei costi massimo e minimo di prodotti
1)	Input dati
2)	Costo Prodotto pi� alto
3)	Costo Prodotto pi� basso
4)	Fine
N.B. i punti 2,3 non possono essere eseguiti se non � stato prima eseguito il punto1
*/
#include <iostream>
using namespace std;

bool controlloinput(){
	bool in=true;
	if(cin.fail()){ // input completamente errato
			cin.clear();
			cin.ignore(800,'\n');
			in=false;
	}else{ // input parzialmente errato
			cin.ignore(800,'\n');
			if((cin.gcount())>1){
				in=false;
		}
	}
	return in;
}

void input_dati(string n1, string n2, string n3,int &q1,int &q2, int &q3,double &p1, double &p2, double &p3){
	cout << "Inserisci il nome del prodotto 1: "<<endl;
	cin >>n1;
	cout << "Inserisci il prezzo del prodotto 1: "<<endl;
	cin >>p1;
	cout << "Inserisci la quantit� del prodotto 1: "<<endl;
	cin >>q1;
	cout << "\nInserisci il nome del prodotto 2: "<<endl;
	cin >>n2;
	cout << "Inserisci il prezzo del prodotto 2: "<<endl;
	cin >>p2;
	cout << "Inserisci la quantit� del prodotto 2: "<<endl;
	cin >>q2;
	cout << "\nInserisci il nome del prodotto 3: "<<endl;
	cin >>n3;
	cout << "Inserisci il prezzo del prodotto 3: "<<endl;
	cin >>p3;
	cout << "Inserisci la quantit� del prodotto 3: "<<endl;
	cin >>q3;
}

double calcola_max(double c1, double c2, double c3){
	double max=c1;
	if(c2>max){
		max=c2;
	}
	if(c3>max){
		max=c3;
	}
	return max;
}

double calcola_min(double c1, double c2, double c3){
	double min=c1;
	if(c2<min){
		min=c2;
	}
	if(c3<min){
		min=c3;
	}
	return min;
}

int Menu(void)
{
	int scelta;
	do{
		   system("CLS");
		cout <<"\n\n\t ********** Men� programma ***********\n";
		cout << "\t 1.Input dati"<<endl;
		cout << "\t 2.Costo Prodotto pi� alto"<<endl;
		cout << "\t 3.Costo Prodotto pi� basso"<<endl;
		cout << "\t 4.Fine"<<endl;
		
		cout <<"\t Inserire scelta (1, 2, 3, oppure 4)   :    ";
		fflush(stdin);
		cin>>scelta;		
		if (controlloinput()==false || (scelta < 1) || (scelta > 4))  {
			cout << "\n\nERRORE!!! Digitare la scelta corretta....\n\n";
			system("PAUSE");
			scelta=0;
		      
		}
	}while ((scelta < 1) || (scelta > 4));
	return scelta;
}

// 
void stampa(double costo, int tipo){
	if(tipo==1){
		cout << "\n\n Il costo del prodotto pi� alto �: "<<costo<<endl;
	}
	if(tipo==2){
		cout << "\n\n Il costo del prodotto pi� basso �: "<<costo<<endl;
	}

}

int main(){
		
	setlocale(LC_ALL, "Italian");
	string n1,n2,n3;
	int q1,q2,q3;
	double p1,p2,p3;
	double c1,c2,c3;	// variabili che memorizzano i costi dei prodotti
	double max_costo,min_costo;
	int scelta;
	bool input=false;

	do{
		    // ripulisco lo schermo
	    system("CLS");
		    // chiamo la funzione che crea il men� utente
	    scelta = Menu();
	    switch (scelta){
	      case 1: 
	      		cout <<"\n\n************* Input Dati************"<<endl;
	      		input_dati(n1,n2,n3,q1,q2,q3,p1,p2,p3);
	      		c1=p1*q1;
	      		c2=p2*q2;
	      		c3=p3*q3;
	      		input=true;
			  	break;
	      case 2: 
		   		if(input==true){
	      			cout <<"\n\nProdotto dal costo pi� alto"<<endl;
	      			max_costo=calcola_max(c1,c2,c3);
	      			stampa(max_costo,1);
				}else{
					cout << "\n\nDati non inseriti!! Inserisci prima i dati"<<endl;
				}
			  	break;
	      case 3: 
	      		if (input==true){
	      			cout <<"\n\nProdotto dal costo pi� basso"<<endl;
	      			min_costo=calcola_min(c1,c2,c3);
	      			stampa(min_costo,2);
				}else{
					cout << "\n\nDati non inseriti!! Inserisci prima i dati"<<endl;
				}
	      	
			  	break;
	      case 4:
		       	 cout <<"\n\nGrazie per aver utilizzato il programma... \n\n";
		        
		        break;
		}
		system("PAUSE");
	}while (scelta != 4);
 // 	system("PAUSE");	  



}

