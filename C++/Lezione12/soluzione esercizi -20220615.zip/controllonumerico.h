using namespace std;
bool controllonumerico(){
	bool r=true;
	if(cin.fail()){	//input errato
			cout << "errore!! inserimento errato!!"<<endl;
			cin.clear();
			cin.ignore(1000,'\n');
			r=false;
	}else{		// caso di input parzialmente
			cin.ignore(1000,'\n');
			if(cin.gcount()>1){
				cout << "errore!! inserimento errato!!"<<endl;
				r=false;
			}
			
	}
	return r;
}

