#include <iostream>
#include "controlloinput.h"
using namespace std;

struct nodo {
    string nome,cognome;
    string indirizzo;
    string telefono;
    nodo *next;
};

nodo *InputDati(nodo *p){
 	cout << "inserisci il Nome: " <<endl;
	getline(cin, p->nome);
	cout << "inserisci il Cognome:" << endl;
	getline(cin, p->cognome);
	cout << "inserisci indirizzo: "<< endl ;
	getline(cin, p->indirizzo);
	cout << "inserisci il telefono"<< endl;
	getline(cin, p->telefono);
	return p;
}

// funzione che crea un nodo della LISTA CONCATENATA e ritorna il puntatore al nodo creato
nodo *creaNodo(void){
	nodo *p;
	p = new nodo;		//  creo un nodo da inserire nella lista
	p=InputDati(p);
	return p;
}

// funzione che inserisce il nodo in testa alla LISTA CONCATENATA, modificando il puntatore di testa (passato per indirizzo)
nodo *inserisciINTESTA(nodo *p,nodo *testa){
	p->next=testa;  // vecchio valore della testa che era NULL lo metto nel nuovo nodo
	testa=p;		// il puntatore di testa deve puntare al nuovo nodo
}

string inputNome(){
	string nome;
 	cout << "inserisci il Nome: " <<endl;
	getline(cin, nome);
	return nome;
}; 

nodo *cercaNomeInRubrica(nodo *testa, string n){
    nodo *p = testa;
    while (p->next!=NULL && p->nome!=n){
		p=p->next;
    }
    if(p->nome!=n){ // se non ho trovato il nome imposto P=NULL
    	p=NULL;
	}
	return p;	
}


void modificaTelefono(nodo *p){
		string telefono;
       cout << "Inserire nuovo numero di telefono: ";
        getline(cin,telefono);
        p->telefono=telefono;
}

StampaTelefono(nodo *p){
	    cout << "Numero di telefono: ";
        cout<< p->telefono<<endl;
}
void stampa_lista(nodo *testa){
    int i=1;
    cout << "############ Stampa Rubrica Telefonica ############" << endl;
    while(testa!=NULL){
        cout <<  i<<")" <<testa->nome << " " << testa->cognome << " tel. " << testa->telefono <<" "<<testa->indirizzo<< endl;
        testa=testa->next; 
        i++;
    }
}

nodo *cancellaContatto(nodo *testa,string nome){	
	int i=0;
	bool trovato=false;
	nodo *p, *prec;
	p = testa;
	prec=testa;
	while(p!=NULL){		//scorro la LISTA dalla testa (p � posizionato al valore di testa)
		i++;
		if(p->nome==nome){
			// elemento trovato
			trovato=true;
			if(i==1){	 //se i=1 sto estraendo il primo nodo
				testa=p->next; // se trovato al primo nodo devo modificare la testa
				delete p;
			}else{	// altrimenti sto estraendo da un nodo successivo al primo
				prec->next=p->next;	// il puntatore del nodo precedente  deve puntare  dove puntava p (che deve essere cancellato)
				delete p;
			}
			break;	// ho trovato il nodo cercato esco dal while in modo da conservare il valore di i che � la posizione del nodo
		}	
		
		prec=p;
		p=p->next;	
	}
	return testa;		// ritorna la testa nel caso sia stata modificata 

}

// scambia i valori di due nodi (senza scambiare i puntatori)
void scambia( nodo *p1, nodo *p){
	string tmp=p1->nome;
	p1->nome=p->nome;
	p->nome=tmp;

	string tmp2=p1->cognome;
	p1->cognome=p->cognome;
	p->cognome=tmp2;
	
	string tmp3=p1->telefono;
	p1->telefono=p->telefono;
	p->telefono=tmp3;

	string tmp4=p1->indirizzo;
	p1->indirizzo=p->indirizzo;
	p->indirizzo=tmp4;	
}

void  ordina(nodo *testa)
{
	bool k;
	do {
        nodo *p = testa;
		k = false;
		while (p->next!=NULL) {
				nodo *p1 = p;
				p = p->next;
				if ((p1->cognome) > (p->cognome)) {
					scambia(p1,p);
					k = true;
				}
		}
	} while (k != false);
}


// FUNZIONE DI CREAZIONE DEL MENU' UTENTE
int Menu(void)
{
	int scelta;
	do{
		system("CLS");
		cout << "\n\n\t************ Gestione RUBRICA TELEFONICA ********* "<<endl<<endl;
		cout <<"\n\t ********** Men� programma ***********\n";
		cout << "\t 1.Inserimento contatto"<<endl;
		cout << "\t 2.Modifica numero di telefono per nome"<<endl;
		cout << "\t 3.Stampa rubrica telefonica ordinata per Cognome"<<endl;
		cout << "\t 4.Eliminazione numero di telefono"<<endl;
		cout << "\t 5.Stampa numero di telefono ricercato per nome"<<endl;
		cout << "\t 6.Fine"<<endl<<endl;
		
 		cout <<"\t Inserire scelta (1, 2, 3, 4,5  oppure 6)   :    ";
		cin>>scelta;		
		if( controlloinputnumerico()==false || (scelta <1 )|| (scelta >6)){
			cout << "\nERRORE!!! Digitare la scelta corretta....\n\n";
			system("PAUSE");
			scelta=0;
		}
	}while ((scelta < 1) || (scelta > 6));
	return scelta;
}

int main(){
	setlocale(LC_ALL, "Italian");
	string n;
    nodo *testa=NULL;
    nodo *p;
//    int scelta,r,pos=0,numeroDaModificare;
	int scelta;
	do{
		    // ripulisco lo schermo
	    system("CLS");
		    // chiamo la funzione che crea il men� utente
	    scelta = Menu();
	    switch (scelta){
		  case 1: 
			cout << "\t 1.Inserimento contatto"<<endl;
			p=creaNodo();
			testa=inserisciINTESTA(p, testa ); 
			cout << "elemento " << p->nome << " inserito IN TESTA ALLA LISTA" << endl;
			break;
	      case 2: 
            if(testa!=NULL){
				cout << "\t 2.Modifica numero di telefono per nome"<<endl;
				string n=inputNome(); // prendo in input il nome da ricercare 
				p=cercaNomeInRubrica(testa,n);  //ricerco il nome in rubrica
				if(p!=NULL){
					cout <<"N. telefono da modificare "<<p->telefono<<endl;
					modificaTelefono(p);     // modifico il telefono 
				}else{
					cout << "numero non trovato in rubrica!!!"<<endl;
				}
            }else{
                cout << "rubrica Vuota" << endl;
            }
 	      
			  	break;
	      case 3: 
            if(testa!=NULL){
	 			cout << "\t 3.Stampa rubrica telefonica ordinata per Cognome"<<endl;
          	 	ordina(testa);
                stampa_lista(testa);
            }else{
                cout << "rubrica Vuota" << endl;
            }
 			break;
	      case 4: 
            if(testa!=NULL){
				cout << "\t 4.Eliminazione numero di telefono"<<endl;
				string n=inputNome(); // prendo in input il nome da ricercare 
				p=cercaNomeInRubrica(testa,n);  //ricerco il nome in rubrica
				if (p!=NULL){
					cout <<"Elimino N. telefono  "<<p->telefono<<endl;
					testa=cancellaContatto(testa,n);     // cancello il telefono 
					cout<<" contatto cancellato!!"<<endl;
				}else{
					cout << "numero non trovato in rubrica!!!"<<endl;
				}

            }else{
                cout << "rubrica Vuota" << endl;
            }
			  	break;
	      case 5: 
           if(testa!=NULL){
           		nodo *t;
				cout << "\t 5.Stampa numero di telefono per nome"<<endl;
				n=inputNome(); // prendo in input il nome da ricercare 
				t=cercaNomeInRubrica(testa,n);  //ricerco il nome in rubrica
				if(t!=NULL){
					StampaTelefono(t);     // modifico il telefono 
				}else{
					cout << "numero non trovato in rubrica!!!"<<endl;
				}
	      	}else{
                cout << "rubrica Vuota" << endl;
            }
			break;
	      case 6:
		       	 cout <<"\n\nGrazie per aver utilizzato il programma... \n\n";
 			  	break;
		}
		system("PAUSE");
	}while (scelta != 6);
	  
}

