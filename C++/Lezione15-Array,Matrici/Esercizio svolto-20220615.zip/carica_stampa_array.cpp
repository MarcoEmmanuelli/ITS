//Autore: Valentino Armando
#include <iostream>
#define DIM 50
using namespace std;

int leggidimensione(int max){
	int dim;
	do{
		cout <<"inserisci il numero di elementi che vuoi caricare: (da 1 a "<<max<<" )"<<endl;
		cin >> dim;
	}while(!(dim>=1 && dim <=max));
	
	return dim;
}

void leggiVettore(double miovettore[], int max){
	for(int i=0; i<max; i++){
		cout << "inserisci l'elemento "<<i+1<<endl;
		cin >>miovettore[i];
	}
}

void stampaVettore(double miovettore[], int max){
	for(int i=0; i<max; i++){
		cout << "stampa l'elemento "<<i<<": "<<miovettore[i]<<endl;
	}
}

int main(){
	double miovettore[DIM];
	int n=leggidimensione(DIM);
	leggiVettore(miovettore, n);
	stampaVettore(miovettore, n);
	
	return 0;
}

