//Prendere due nomi e due date di nascita di due persone
//Stampare in ordine alfabetico di data o di nome su richiesta di input
#include <iostream>
using namespace std;
int main (){
	string data1,data2,nome1,nome2;
	char c;
	cout<< "Inserisci il primo nome:\t";	
	getline(cin,nome1);
	cout<< "Inserisci data di nascita (DD/MM/YYYY):\t";	
	getline(cin,data1);
	cout<< "Inserisci il secondo nome:\t";	
	getline(cin,nome2);
	cout<< "Inserisci data di nascita (DD/MM/YYYY):\t";	
	getline(cin,data2);
	cout<< "In che ordine vuoi vedere i dati? Data <d> o Nome <n>? \t";	
	fflush(stdin);
	c = getchar();
	if (c == 'd' || c == 'D'){
		string g1, m1, a1, g2, m2, a2;
		g1 = data1.substr(0,2);
		m1 = data1.substr(3,2);
		a1 = data1.substr(6,4);
		
		g2 = data2.substr(0,2);
		m2 = data2.substr(3,2);
		a2 = data2.substr(6,4);
		
		cout<<"\n Stampo in ordine di data:\n";
		
		if(a1<a2){
			cout<<data1 + " - " + nome1 + "\n"+ data2 + " - " + nome2<<endl<<endl;
		}
		else{
			if(a1==a2){
				if(m1<m2){
					cout<<data1 + " - " + nome1 + "\n"+ data2 + " - " + nome2<<endl<<endl;
				}
				else{
					if(m1==m2){
						if(g1<g2){
							cout<<data1 + " - " + nome1 + "\n"+ data2 + " - " + nome2<<endl<<endl;
						}
						else
							cout<<data2 + " - " + nome2 + "\n"+ data1 + " - " + nome1<<endl<<endl;
					}
					else{
						cout<<data2 + " - " + nome2 + "\n"+ data1 + " - " + nome1<<endl<<endl;
					}
				}
			}
			else{
				cout<<data2 + " - " + nome2 + "\n"+ data1 + " - " + nome1<<endl<<endl;
			}
		}
	}
	else{
		if(c == 'n' || c == 'N'){
			cout<<"\n Stampo in ordine di nome:\n";
			if (nome1 < nome2)
				cout<<nome1 + " - " + data1 + "\n"+ nome2 + " - " + data2<<endl<<endl;
			else
				cout<<nome2 + " - " + data2 + "\n"+ nome1 + " - " + data1<<endl<<endl;
		}
		else
			cout << "Input sbagliato. Riavvia il programma!"<<endl<<endl;
	}
	
	system("pause");
	return 0;
	
}
