// Prendere due nomi e due date di nascita di due personee stampare in ordine alfabetico  di data o di nome su richiesta
// di input
#include <iostream>
using namespace std;
int main(){
	string data1,data2,nome1,nome2;
	cout<<"Inserire il primo nome: "<<endl;
	cin>>nome1;
	cout<<"Inserire la data di nascita di "<<nome1<<" (yyyy/mm/dd): "<<endl;
	cin>>data1;
	cout<<"Inserire il secondo nome: "<<endl;
	cin>>nome2;
	cout<<"Inserire la data di nascita di "<<nome2<<" (yyyy/mm/dd): "<<endl;
	cin>>data2;
	int answ=0;
	cout<<"Scegli:"<<endl;
	cout<<"1) Ordinamento in base al nome."<<endl;
	cout<<"2) Ordinamento in base alla data di nascita."<<endl;
	cin>>answ;	
	if(answ==1){
		cout<<"Ordino in base al nome: "<<endl;
		if(nome1<nome2){
			cout<<"Nome: "<<nome1<<" | Data di nascita: "<<data1<<endl;
			cout<<"Nome: "<<nome2<<" | Data di nascita: "<<data2<<endl;
		}else{
			cout<<"Nome: "<<nome2<<" | Data di nascita: "<<data2<<endl;
			cout<<"Nome: "<<nome1<<" | Data di nascita: "<<data1<<endl;			
		}
	}else if(answ==2){
		cout<<"Ordino in base alla data: "<<endl;
		if(data1<data2){
			cout<<"Nome: "<<nome1<<" | Data di nascita: "<<data1<<endl;
			cout<<"Nome: "<<nome2<<" | Data di nascita: "<<data2<<endl;
		}else{
			cout<<"Nome: "<<nome2<<" | Data di nascita: "<<data2<<endl;
			cout<<"Nome: "<<nome1<<" | Data di nascita: "<<data1<<endl;			
		}
	}else{
		cout<<"Input errato!"<<endl;
	}
	
	fflush(stdin);
	getchar();	
	return 0;
}
