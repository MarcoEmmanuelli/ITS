#include <iostream>
using namespace std;
int main()
{
	string n1, n2, n3;
	cout << "inserire 3 nomi: \nNome 1:";
	cin >> n1;
	cout << "\nNome 2: ";
	cin >> n2; 
	cout << "\nNome 3: ";
	cin >> n3;
	if(n1<n2 && n1<n3)
	{
		cout << n1 << endl;
		if (n2<n3)
		{
			cout << n2 << endl;
			cout << n3;
		}
		else
		{
			cout << n3 << endl;
			cout << n2;
		}
	}
	else if(n2<n1 && n2<n3)
	{
		cout << n2 << endl;
		if (n1<n3)
		{
			cout << n1 << endl;
			cout << n3;
		}
		else
		{
			cout << n3 << endl;
			cout << n1;
		}
	}
	else
	{
		cout << n3 << endl;
		
		if (n1<n2)
		{
			cout << n1 << endl;
			cout << n2;
		}
		else
		{
			cout << n2 << endl;
			cout << n1;
		}
	}
		
}
