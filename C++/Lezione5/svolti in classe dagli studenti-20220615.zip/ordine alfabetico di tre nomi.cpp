//ordine alfabetico di tre nomi
#include<iostream> 
using namespace std;
int main(){ 
string nome1,nome2,nome3;
cout<<"inserisci il primo nome: ";
getline(cin,nome1);
cout<<"inserisci il secondo nome: ";
getline(cin,nome2);
cout<<"inserisci il terzo nome: ";
getline(cin,nome3);
cout<<"stampa dei nomi in ordine alfabetico:"<<endl;
if(nome1<nome2 && nome1<nome3 && nome2<nome3) {        // 1  2  3                           
  cout<<nome1<<endl<<nome2<<endl<<nome3<<endl;         	 
}
else if(nome1<nome2 && nome1<nome3 && nome3<nome2) {   // 1  3  2 
	 cout<<nome1<<endl<<nome3<<endl<<nome2<<endl; 
}
else if(nome2<nome1 && nome2<nome3 && nome1<nome3) {   // 2  1  3
   cout<<nome2<<endl<<nome1<<endl<<nome3<<endl;            
}
else if(nome2<nome3 && nome2<nome1 && nome3<nome1) {  // 2  3  1
   cout<<nome2<<endl<<nome3<<endl<<nome1<<endl;
}
else if(nome3<nome2 && nome3<nome1 && nome2<nome1) {  //  3  2  1  
	cout<<nome3<<endl<<nome2<<endl<<nome1<<endl;
}
else if(nome3<nome1 && nome3<nome2 && nome1<nome2) {  // 3  1  2
    cout<<nome3<<endl<<nome1<<endl<<nome2<<endl;
}
fflush(stdin);
getchar();
}
