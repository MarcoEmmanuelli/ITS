#include <iostream>
#include <conio.h>
using namespace std;

int main(){
	char car1,car2,car3;
	cout << "inserisci il primo carattere (nascosto)"<<endl;
	car1=getch();
	cout << " inserisci secondo carattere <enter>"<<endl;
	car2=getchar();
	cout << " inserisci terzo carattere "<<endl;
	car3=getche();
	cout << "\n I tre caratteri letti sono : "<<car1<<" "<<car2<<" "<<car3;
	cout <<endl;
	fflush(stdin);
	getchar();


}
