//calcolo e conversione della valuta euro dollaro
#include <iostream>
#define EuroLira 1936.27
const float EuroDollaro=1.3676;
using namespace std;

int main(){
 float valore1,valore2;
 valore1=100/EuroLira;
 valore2=valore1*EuroDollaro;
 cout << "calcolo 100 lire in Euro: "<< valore1<< " in Dollari: "<< valore2;
 cout << endl;
 valore1=10000/EuroLira;
 valore2=valore1*EuroDollaro;
 cout << "calcolo 10000 lire in Euro: "<< valore1<< " in Dollari: "<< valore2;
 cout << endl;
 
}
