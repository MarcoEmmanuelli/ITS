#include <iostream>
#include <cmath>
using namespace std;
int main(){
	float a=-100.5;
	cout <<"valore assoluto "<< abs(a)<<endl;	// valore assoluto del numero
	cout <<"radice qudrata "<< sqrt(-a)<<endl; // radice quadrata
	cout << "minimo intero non minore di a "<<ceil(a)<<endl; // minimo intero non minore di a
	cout << "massimo intero non maggiore di a "<<floor(a)<<endl; //massimo intero non maggiore di a
	cout <<"logaritmo naturale di a "<< log(-a)<<endl;   // logaritmo naturale di a
	cout <<"logaritmo base 10 di a "<< log10(-a)<<endl; //logaritmo base 10 di a
	getchar();
}


