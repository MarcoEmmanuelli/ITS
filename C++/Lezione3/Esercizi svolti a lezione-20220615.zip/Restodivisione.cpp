// calcola il resto della divisione di 3 numeri
#include <iostream>
using namespace std;
int main(){
 int num1,num2,num3;
 int resto1,resto2,resto3,resto4,resto5,resto6;
 cout << "inserisci tre numeri interi:\n";
 cout << "numero 1: ";
 cin >> num1;
 cout << "numero 2: ";
 cin >> num2;
 cout << "numero 3: ";
 cin >> num3;
 resto1=num1%num2;
resto2=num1%num3;	
resto3=num2%num3;
resto4=num2%num1;
resto5=num3%num2;
resto6=num3%num1;
cout << "resto della divisione :"<<endl;
cout << "num1 % num2: "<<resto1<<endl;
cout << "num1 % num3: "<<resto2<<endl;
cout << "num2 % num3: "<<resto3<<endl;
cout << "num2 % num1: "<<resto4<<endl;
cout << "num3 % num2: "<<resto5<<endl;
cout << "num3 % num1: "<<resto6<<endl;
cout << endl;
}
