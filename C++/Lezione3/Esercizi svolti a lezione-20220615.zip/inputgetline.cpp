// input di stringhe da tastiera e uso della funzione getline()
#include <iostream>
using namespace std;
int main(){
	string titolo,autore, editore;
	int numpagine;
	float prezzo;
	cout << "inserisci il Titolo;"<<endl;
	getline(cin,titolo);
	cout <<endl<< "inserisci l'autore:"<<endl;
	getline(cin,autore);
	cout << endl<<"inserisci il numero delle pagine"<<endl;
	cin >>numpagine;
	cout << endl<<"inserisci il prezzo"<<endl;
	cin >> prezzo;
	fflush(stdin);
	cout <<endl<< "inserisci l'editore:"<<endl;
	getline(cin,editore);

	cout <<endl<<"dati del libro:"<<endl;
	cout << titolo<<endl;
	cout << autore<<endl;
	cout << editore<<endl;
	cout << numpagine<<endl;
	cout << prezzo<<endl;
}
